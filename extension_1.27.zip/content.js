var storageKeys = /* @__PURE__ */ ((storageKeys2) => {
  storageKeys2["USER_SETTINGS"] = "userSettings";
  storageKeys2["AI_CONFIG"] = "aiConfig";
  storageKeys2["API_KEY"] = "apiKey";
  storageKeys2["AI_MODEL"] = "aiModel";
  storageKeys2["AI_PROMPT"] = "aiSystemPrompt";
  storageKeys2["IMAGE_SRC"] = "imageSrc";
  storageKeys2["CRITERIA_RULES"] = "criteriaRules_v1";
  storageKeys2["DEFAULT_CRITERIA"] = "defaultCriteria";
  storageKeys2["CRITERIA_HEADER"] = "criteriaHeader";
  storageKeys2["CRITERIA_TABLE_CELL_SIZE"] = "criteriaTableCellSize";
  storageKeys2["COLS_WIDTH"] = "colsWidth";
  storageKeys2["ROWS_HEIGHT"] = "rowsHeight";
  storageKeys2["PAGE_MARKS"] = "pageMarks";
  storageKeys2["MARK_HISTORY"] = "markHistory";
  storageKeys2["STATISTICS"] = "statistics";
  storageKeys2["USAGE_STATS"] = "usageStats";
  storageKeys2["TEMP_DATA"] = "tempData";
  storageKeys2["SESSION_DATA"] = "sessionData";
  storageKeys2["EXTENSION_STATUS"] = "extensionStatus";
  storageKeys2["LAST_SYNC"] = "lastSync";
  storageKeys2["CACHE_DATA"] = "cacheData";
  storageKeys2["IMAGE_CACHE"] = "imageCache";
  storageKeys2["DIV_POSITIONS"] = "div_positions";
  storageKeys2["TOTAL_SCORE"] = "total_score";
  storageKeys2["UPDATE_INFO"] = "updateInfo";
  return storageKeys2;
})(storageKeys || {});
function parseAIResult2(aiResult) {
  return aiResult.choices[0].message.content;
}
console.log("content.ts loaded");
const testPageHandlers = {
  submit: () => {
    document.dispatchEvent(new CustomEvent("customSubmit"));
  },
  getImageSrc: () => {
    const cardImage = document.getElementById("cardImage");
    return cardImage.src;
  },
  setTotalScore: (score) => {
  }
};
const overlay = document.createElement("div");
overlay.style.top = "0";
overlay.style.left = "0";
overlay.style.zIndex = "9999";
const wyPageHandlers = {
  submit: () => {
    overlay.remove();
  },
  getImageSrc: () => {
    const targetElement = document.querySelector(
      ".imgSection.clear>img"
    );
    return targetElement?.src;
  },
  setTotalScore: (score) => {
    const inputOne = document.getElementById("inputOne");
    if (inputOne) {
      inputOne.value = score.toString();
      inputOne.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
};
const { submit, getImageSrc, setTotalScore } = location.host.includes(
  "www.wylkyj.com"
) ? wyPageHandlers : testPageHandlers;
let previousSrc = "";
let isDragging = false;
let currentElement = null;
let startX = 0;
let startY = 0;
let initialX = 0;
let initialY = 0;
const POSITION_STORAGE_KEY = storageKeys.DIV_POSITIONS;
const TOTAL_SCORE_KEY = storageKeys.TOTAL_SCORE;
const getStoredPositions = () => {
  try {
    const data = localStorage.getItem(POSITION_STORAGE_KEY);
    return data ? JSON.parse(data) : {};
  } catch (e) {
    console.error("Error loading stored positions:", e);
    return {};
  }
};
const savePosition = (id, left, top) => {
  try {
    const positions = getStoredPositions();
    positions[id] = { left, top };
    localStorage.setItem(POSITION_STORAGE_KEY, JSON.stringify(positions));
  } catch (e) {
    console.error("Error saving position:", e);
  }
};
let totalScore = 0;
const calculateTotalScore = (res) => {
  return res.reduce((sum, [, score]) => sum + Number(score), 0);
};
const saveTotalScore = (score) => {
  try {
    localStorage.setItem(TOTAL_SCORE_KEY, score.toString());
  } catch (e) {
    console.error("Error saving total score:", e);
  }
};
const setupKeyboardListeners = () => {
  document.addEventListener("keydown", (e) => {
    switch (e.key) {
      case "ArrowUp":
        e.preventDefault();
        totalScore++;
        setTotalScore(totalScore);
        saveTotalScore(totalScore);
        break;
      case "ArrowDown":
        e.preventDefault();
        totalScore = Math.max(0, totalScore - 1);
        setTotalScore(totalScore);
        saveTotalScore(totalScore);
        break;
      case " ":
        e.preventDefault();
        totalScore = 0;
        setTotalScore(totalScore);
        saveTotalScore(totalScore);
        break;
      case "Enter":
        e.preventDefault();
        submit();
        break;
    }
  });
};
setupKeyboardListeners();
const makeDraggable = (element, id) => {
  element.style.cursor = "move";
  element.style.userSelect = "none";
  const positions = getStoredPositions();
  if (positions[id]) {
    element.style.left = `${positions[id].left}px`;
    element.style.top = `${positions[id].top}px`;
  }
  element.addEventListener("mousedown", (e) => {
    isDragging = true;
    currentElement = element;
    startX = e.clientX;
    startY = e.clientY;
    initialX = parseInt(element.style.left || "0", 10);
    initialY = parseInt(element.style.top || "0", 10);
    e.preventDefault();
  });
  element.id = id;
};
document.addEventListener("mousemove", (e) => {
  if (!isDragging || !currentElement) return;
  const dx = e.clientX - startX;
  const dy = e.clientY - startY;
  currentElement.style.left = `${initialX + dx}px`;
  currentElement.style.top = `${initialY + dy}px`;
});
document.addEventListener("mouseup", () => {
  if (isDragging && currentElement && currentElement.id) {
    const left = parseInt(currentElement.style.left || "0", 10);
    const top = parseInt(currentElement.style.top || "0", 10);
    savePosition(currentElement.id, left, top);
  }
  isDragging = false;
  currentElement = null;
});
let scores = [];
chrome.storage.local.get(storageKeys.CRITERIA_RULES).then((res) => {
  const rules = res[storageKeys.CRITERIA_RULES];
  if (rules) {
    scores = rules.map(([_, score]) => score);
    console.log(scores);
  }
});
const showAiResult = (result) => {
  try {
    const res = JSON.parse(result);
    console.log(res);
    document.body.appendChild(overlay);
    overlay.innerHTML = "";
    totalScore = calculateTotalScore(res);
    setTotalScore(totalScore);
    res.forEach(([text, score, reason], index) => {
      const div = document.createElement("div");
      div.style.position = "absolute";
      div.style.left = `${50 + index * 20}px`;
      div.style.top = `${150 + index * 40}px`;
      div.innerText = `${text}(${score}分,${reason})`;
      div.style.padding = "5px 10px";
      div.style.border = "1px solid #ccc";
      div.style.borderRadius = "4px";
      div.style.fontSize = "14px";
      let color = "";
      if (score.toString() === "0") {
        color = "red";
      } else if (!scores[index] || score.toString() === scores[index]) {
        color = "green";
      } else {
        color = "blue";
      }
      div.style.color = color;
      overlay.appendChild(div);
      const uniqueId = `result-div-${index}`;
      makeDraggable(div, uniqueId);
    });
  } catch (e) {
    console.error(e);
  }
};
let showedResult = false;
const h = async () => {
  let delay = 500;
  const currentSrc = getImageSrc();
  if (currentSrc && (currentSrc !== previousSrc || !showedResult)) {
    showedResult = false;
    delay = 1e3;
    console.log("Image src changed:", currentSrc);
    previousSrc = currentSrc;
    const res = await chrome.runtime.sendMessage({
      action: "getAIResult",
      url: currentSrc
    });
    console.log(res);
    const result = res?.result;
    if (result) {
      showedResult = true;
      const aiResult = parseAIResult2(result);
      showAiResult(aiResult);
    } else {
      console.error("No result from AI");
    }
  }
  setTimeout(h, delay);
};
h();
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "syncCurrentImage") {
    const currentSrc = getImageSrc();
    chrome.runtime.sendMessage({
      action: "getResponse",
      url: currentSrc
    }).then((res) => {
      if (res?.dataUrl) {
        sendResponse({
          dataUrl: res.dataUrl
        });
      } else {
        sendResponse({
          dataUrl: ""
        });
      }
    });
  }
  return true;
});
