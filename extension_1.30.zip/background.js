import { e as scaleImage, g as getImageBitmap, r as recognizeImage, s as storageKeys, c as checkUpdate } from "./update-DS-Gghjo.js";
const printImageInConsole = (url, width, height) => {
  const num = (width / height | 0) * 2;
  console.log(num);
  console.log(
    "%c" + " ".repeat(num),
    `font-size:${height}px;line-height:${height}px;background:url("${url}") no-repeat;background-size:contain;background-position:center;`
  );
};
let urlResultMap = /* @__PURE__ */ new Map();
async function aiHook(url, dataUrl) {
  if (urlResultMap.has(url)) {
    return;
  }
  const scaledDataUrl = await scaleImage(dataUrl);
  const bitmap = await getImageBitmap(scaledDataUrl);
  printImageInConsole(scaledDataUrl, bitmap.width, bitmap.height);
  bitmap.close();
  const result = recognizeImage(scaledDataUrl);
  urlResultMap.set(url, result);
  urlResultMap = new Map([...urlResultMap.entries()].slice(-20));
  result.catch(() => {
    urlResultMap.delete(url);
  });
}
const getAIResultHandler = (request, sender, sendResponse) => {
  setTimeout(() => {
    const pendingResult = urlResultMap.get(request.url);
    console.log("getAIResult", request.url, pendingResult);
    if (pendingResult) {
      console.log("getAIResult found");
      pendingResult.then(
        (result) => {
          sendResponse({ result });
        },
        (error) => {
          console.error("Error fetching AI result:", error);
          sendResponse({ error: String(error) });
        }
      );
    } else {
      console.log("getAIResult not found");
      sendResponse({ error: "No result found" });
    }
  });
};
const requestIdResponseMap = /* @__PURE__ */ new Map();
let urlResponseMap = /* @__PURE__ */ new Map();
const attachedTabs = /* @__PURE__ */ new Map();
const debuggerEnabledUrls = [
  "http://127.0.0.1:8080/dist/doc/test/",
  "https://marking.xna00.top/test/",
  "https://www.wylkyj.com/",
  "https://wylkyj.com/"
];
const logUrls = [
  "http://127.0.0.1:8080/dist/doc/test/images/",
  "https://marking.xna00.top/image",
  "https://data.wylkyj.com/PaperScan/",
  "https://data.wylkyj.com/AnswerSheet/"
];
const attachAndEnableNetwork = async (tabId, tab) => {
  if (!attachedTabs.get(tabId)) {
    try {
      await chrome.debugger.attach({ tabId }, "1.3");
      await chrome.debugger.sendCommand({ tabId }, "Network.enable");
      attachedTabs.set(tabId, true);
      console.log("Debugger attached to:", tabId, tab.url);
    } catch (e) {
      console.error("Failed to attach debugger:", e);
    }
  }
};
const detachDebugger = async (tabId) => {
  if (attachedTabs.get(tabId)) {
    try {
      await chrome.debugger.detach({ tabId });
      attachedTabs.set(tabId, false);
      console.log("Debugger detached from:", tabId);
    } catch (e) {
      console.error("Failed to detach debugger:", e);
    }
  }
};
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && debuggerEnabledUrls.some((url) => tab.url.includes(url))) {
    attachAndEnableNetwork(tabId, tab);
  } else if (attachedTabs.get(tabId) && tab.url && !debuggerEnabledUrls.some((url) => tab.url.includes(url))) {
    detachDebugger(tabId);
  }
});
chrome.tabs.onCreated.addListener((tab) => {
  const tabId = tab.id;
  if (!tabId) return;
  if (tab.url && debuggerEnabledUrls.some((url) => tab.url.includes(url))) {
    setTimeout(() => {
      if (!attachedTabs.get(tabId)) {
        attachAndEnableNetwork(tabId, tab);
      }
    }, 1e3);
  }
});
chrome.debugger.onEvent.addListener(async (source, method, rawParams) => {
  if (!source.tabId) return;
  const tabId = source.tabId;
  const params = rawParams;
  if (method === "Network.responseReceived") {
    const responseParams = params;
    if (responseParams.response.mimeType.startsWith("image/") && logUrls.some((url) => responseParams.response.url.includes(url))) {
      requestIdResponseMap.set(responseParams.requestId, responseParams);
    }
  } else if (method === "Network.loadingFinished") {
    const requestId = params.requestId;
    const responseParams = requestIdResponseMap.get(requestId);
    requestIdResponseMap.delete(requestId);
    if (responseParams) {
      const response = await chrome.debugger.sendCommand(
        { tabId },
        "Network.getResponseBody",
        {
          requestId: responseParams.requestId
        }
      );
      console.log("Response body:", response);
      if (!response) {
        console.log("Response is undefined");
        return;
      }
      const responseBody = response;
      let dataUrl = "";
      if (responseBody.base64Encoded) {
        dataUrl = "data:" + responseParams.response.mimeType + ";base64," + responseBody.body;
      } else {
        dataUrl = "data:" + responseParams.response.mimeType + ";charset=utf-8," + encodeURIComponent(responseBody.body);
      }
      urlResponseMap.set(responseParams.response.url, dataUrl);
      urlResponseMap = new Map([...urlResponseMap.entries()].slice(-20));
      aiHook(responseParams.response.url, dataUrl);
      console.log("Response body:", {
        requestId: responseParams.requestId,
        base64Encoded: responseBody.base64Encoded,
        body: responseBody.body,
        dataUrl
      });
    }
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  detachDebugger(tabId);
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getResponse") {
    const dataUrl = urlResponseMap.get(request.url);
    sendResponse({ dataUrl });
  }
});
console.log("Marking extension background script loaded");
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "reloadExtensionAfterUpgrade") {
    chrome.storage.local.set({
      [storageKeys.UPDATE_INFO]: null
    }).then(() => {
      chrome.runtime.reload();
    });
  } else if (message.action === "getAIResult") {
    getAIResultHandler(message, sender, sendResponse);
  } else if (message.action === "hello") {
    sendResponse(`Hello ${sender.url}, I'm background script`);
  }
  return true;
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
chrome.tabs.onCreated.addListener(checkUpdate);
