import { s as storageKeys, c as checkUpdate, H as HOST, m as modelNames, f as fillCriteriaPlaceholder, a as makeCriteriaMDTable, d as defaultAISettings, r as recognizeImage, p as parseAIResult, b as blobToDataUrl, e as scaleImage } from "./update-CJjM2L1O.js";
import { r as requireClient, a as requireReact, g as getDefaultExportFromCjs } from "./vendor-2BUl_Ub7.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production = {};
var hasRequiredReactJsxRuntime_production;
function requireReactJsxRuntime_production() {
  if (hasRequiredReactJsxRuntime_production) return reactJsxRuntime_production;
  hasRequiredReactJsxRuntime_production = 1;
  var REACT_ELEMENT_TYPE = /* @__PURE__ */ Symbol.for("react.transitional.element"), REACT_FRAGMENT_TYPE = /* @__PURE__ */ Symbol.for("react.fragment");
  function jsxProd(type, config, maybeKey) {
    var key = null;
    void 0 !== maybeKey && (key = "" + maybeKey);
    void 0 !== config.key && (key = "" + config.key);
    if ("key" in config) {
      maybeKey = {};
      for (var propName in config)
        "key" !== propName && (maybeKey[propName] = config[propName]);
    } else maybeKey = config;
    config = maybeKey.ref;
    return {
      $$typeof: REACT_ELEMENT_TYPE,
      type,
      key,
      ref: void 0 !== config ? config : null,
      props: maybeKey
    };
  }
  reactJsxRuntime_production.Fragment = REACT_FRAGMENT_TYPE;
  reactJsxRuntime_production.jsx = jsxProd;
  reactJsxRuntime_production.jsxs = jsxProd;
  return reactJsxRuntime_production;
}
var hasRequiredJsxRuntime;
function requireJsxRuntime() {
  if (hasRequiredJsxRuntime) return jsxRuntime.exports;
  hasRequiredJsxRuntime = 1;
  {
    jsxRuntime.exports = requireReactJsxRuntime_production();
  }
  return jsxRuntime.exports;
}
var jsxRuntimeExports = requireJsxRuntime();
var clientExports = requireClient();
var reactExports = requireReact();
const useStateWithChromeStorage = (key, initialValue) => {
  const [value, setValue] = reactExports.useState(initialValue);
  reactExports.useEffect(() => {
    chrome.storage.local.get(key, (result) => {
      setValue(result[key] ?? initialValue);
    });
  }, []);
  reactExports.useEffect(() => {
    chrome.storage.local.set({ [key]: value });
  }, [value]);
  return [value, setValue];
};
let cellSize = (await chrome.storage.local.get(storageKeys.CRITERIA_TABLE_CELL_SIZE))[storageKeys.CRITERIA_TABLE_CELL_SIZE] ?? {
  colsWidth: {
    0: 60,
    1: 100,
    2: 60,
    3: "auto"
  },
  rowsHeight: {
    0: 40
  }
};
const debounce = (func, delay = 200) => {
  let timer;
  return function(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      func.apply(this, args);
    }, delay);
  };
};
const CriteriaTable = ({
  criteriaHeader,
  criteriaRules,
  setCriteriaRules,
  setInputRef
}) => {
  const resizeObserver = new ResizeObserver(
    debounce((entries) => {
      console.log(entries);
      const newCellSize = {
        colsWidth: { ...cellSize.colsWidth },
        rowsHeight: { ...cellSize.rowsHeight }
      };
      for (const entry of entries) {
        const target = entry.target;
        const dataset = target.dataset;
        if (dataset.row) {
          newCellSize.rowsHeight[dataset.row] = entry.borderBoxSize[0].blockSize;
          console.log(dataset.row, entry.borderBoxSize[0].blockSize);
        }
        if (dataset.col && dataset.col !== criteriaHeader.length.toString()) {
          newCellSize.colsWidth[dataset.col] = entry.borderBoxSize[0].inlineSize;
          console.log(dataset.col, entry.borderBoxSize[0].inlineSize);
        }
      }
      cellSize = newCellSize;
      chrome.storage.local.set({
        [storageKeys.CRITERIA_TABLE_CELL_SIZE]: newCellSize
      });
    })
  );
  const observe = (e) => {
    if (e) {
      resizeObserver.observe(e);
    }
  };
  reactExports.useEffect(() => {
    return () => {
      resizeObserver.disconnect();
    };
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { id: "criteriaTable", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { id: "tableHeadRow", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "th",
        {
          ref: observe,
          "data-row": "0",
          "data-col": "0",
          style: {
            width: cellSize.colsWidth[0],
            height: cellSize.rowsHeight[0]
          },
          children: [
            "序号",
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "border rounded-full w-4 h-4 m-auto flex items-center justify-center cursor-pointer",
                onClick: () => {
                  const newRules = [...criteriaRules];
                  newRules.splice(
                    0,
                    0,
                    new Array(criteriaHeader.length).fill("")
                  );
                  setCriteriaRules(newRules);
                },
                children: "+"
              }
            )
          ]
        }
      ),
      criteriaHeader.map((head, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "th",
        {
          ref: observe,
          "data-col": index + 1,
          style: {
            width: cellSize.colsWidth[index + 1]
          },
          children: head
        },
        head
      ))
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { id: "tableBody", children: criteriaRules.map((rule, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "td",
        {
          className: "text-center",
          ref: observe,
          "data-row": i + 1,
          style: {
            height: cellSize.rowsHeight[i + 1] ?? cellSize.rowsHeight[0]
          },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "border rounded-full w-4 h-4 m-auto flex items-center justify-center cursor-pointer",
                onClick: () => {
                  const newRules = [...criteriaRules];
                  newRules.splice(i, 1);
                  setCriteriaRules(newRules);
                },
                children: "-"
              }
            ),
            i + 1,
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "border rounded-full w-4 h-4 m-auto flex items-center justify-center cursor-pointer",
                onClick: () => {
                  const newRules = [...criteriaRules];
                  newRules.splice(
                    i + 1,
                    0,
                    new Array(criteriaHeader.length).fill("")
                  );
                  setCriteriaRules(newRules);
                },
                children: "+"
              }
            )
          ]
        }
      ),
      rule.map((item, j) => /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          className: "absolute inset-0 border-none! outline-none rounded-none",
          value: item,
          onChange: (e) => {
            const newRules = [...criteriaRules];
            newRules[i][j] = e.target.value;
            setCriteriaRules(newRules);
          },
          onFocus: (e) => {
            setInputRef({
              e: e.target,
              setValue: (value) => {
                const newRules = [...criteriaRules];
                newRules[i][j] = value;
                setCriteriaRules(newRules);
              }
            });
          }
        }
      ) }, j))
    ] }, i)) })
  ] }) });
};
const defaultImageUrl = "data:image/webp;base64,UklGRnxuAABXRUJQVlA4WAoAAAAgAAAAwgIAPwEASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDggjmwAAJA7AZ0BKsMCQAE+bTKUR6QioiEmmCp4gA2JaW78eHmr61DI/SL+pfjZ72+636v/af8N/if7p6N/iHx39J/tP+P/w39p/aP4Vf4vwf+h/wv+Y9Cf4p9a/sv9z/yv+w/tf7z/DP+M/sX5Lejv5n+r/3X/D/t9/h/kF/FP5H/bf7N+3P9r/fL7AfoP9h2pmff4j/X/5f2BfUf5j/hv7Z/mP+X/hfRM/lP636jfn/9Z/yn9//IX7AP5H/O/8X/af3d/uv///+n2z/t//F4tH3L/d/t58AP8t/s//U/vv+j/bX6Tv5X/r/5f/VftB7Tfzv/Hf9X/Hf6r/5f7D/////9Bv5V/WP93/gP89/9f89////5973/7/6fwU/dz///9v4Yv3A//v/ALVSOepCGkF31T7GqVtEQSC76p9jVK2iIIpXCHHAykoGi4mStZN+hjKz4MQ4CuAVwjP9+Y5DsgKGX9YCLniBUJf1guE+Bl1IORfv3L8oQqv0BW7Js7i1tcXokys9YnXckzlFVeP2wW4YjYFLDnfojNJPNAehTeZ1zL5Fv2c00ONIjfY9+oA8ZClyZyM8EEPxbP9t0Bmv5mlOqsfTwdmZ/rD2wdfww4oBQPynJS1CTgYw7Yp0Gtxh+HNtX52YpDn8si/WDDLUqqvtInKI474mkdMDqV93rU/VJJ8dnwJAPeUo5qb6GP1QzdbS/5lGzw1U3N5OJs7Jbcp8/a7i6PrvjhAXjt5tw1FtgI94sw3VTARFYYHV2v5FkxdmpeycTXCOqfY1StoiCQXfVPsQbmLYYtZmMkSGPpTzwhCuNNdG5WrENTMPUhMgU3xL6UrcDmTndkgcEV3HmDspKa6ci/DZZs2gri9CoAb6qRz1FO7RbLHYDxLyxKNnt9Vdus48sgvu5WN8IQDIoojeG1WhHiUWNCOqfUHOEE12ph/mDO1ff7FNxYEomlVbYiv8gsZQyXK1vvSOOCrzBOWKqinvYRhSDKlyq3FNzCsSpycpI+J9wGE6HxwZfaiGKM2zPNf3AOhGcpQrJCPHTyZuUptbBhow0o2uhDK6rDI69hSsdUlfnKrmrCX3WBXFv+oz6DyIi17cST+trBkr7Ocn7JtiYGi40q3v+7Nj26kkzH6qEjvXQM2/Gfz3YoUdLqfA0UKiTJzlnujz5LKCloYH4fhyWVk6rtYt+pEyf8x8/2FvlpCucpKcVN0qU1RE1PDbBgJ2sVSIGxwyZeBgObQol7EwgvxNyyZHOlhxmZmvSA4TDhLUiQw19ERIjH/iyR7cPmT/kwU9U+xLc0TbLBcJR8UtxbkIfma2qpxqVwBap0aALrTk0EgK2UKO0cR74Kgq4i7dAEJH28jqn2NT9Xw+yXeKcz+sNj8UKOyz1vCC76p9jVK2iHhhuXs/jBSjYmY7/qVeXqFAiSht7r6jZE74d6hI4p+Ov4hyrSbFOvMbru5jl/H5nubqmeE5HGsDcI/71a3k5zLONIkzJ92YiCnqQhpBd9U+xqlbRDkFF+anIfoKn5H2ByhYhpvQGUh6yvjVK2iIJBIL6p9jRlP7coEwRFPi03BSseLBFZXo6n6VP5QHoPca4YiN125k9aMoSPHKjXx5SawCBtJYHuTuXlnTnpZjmddx7AwOJxUlAN+ixnQgf4Zk3p9iwp4EX66DMnpBVjmpyYdFRCXBDqklijfKp1/tTMvijZ/NCF9ITJnCwuoTrtu/b20LrTc0TwOlLxZ/r/zMVHGMfXCgiup0nfVlxIz0T/zOGF4myCz9Qdr3z1N2ll7bU3tW3yxdaL8+GQRykwbU4N+8V22REmE6+2FcsbkeRod6Iw6tmnFxwI4jzGAwA61WkpVWzZwUnGwFzrQI2r1QnwDAVS01KQuahJvjqZlae3MXytHLpGCckf+4ksNNgsJYvGyQ7SokrK7esDbi511DDy45W6vehbE/lmuNvGbIE+Ixy+bz7LlQsTT9kLP+vycCs+XhMWmdiQ4lHvmjjbztC2sahhJXhBYYnq633KWZ/Yw4UXt9sAXcbbTr+U30xYixbiTOgSoPXbEJh3qSxDsNFCY4uCJT09cskgQ104EQ+RySoyhi10Wq591gc5272mjZ1ss3b91KzpGG98EvJUB4HVqUzxkVwKV1q1Ue4QStQnBon1QWVJ+X8z1E0YPrGI/em/sid9wvzD7CaMZlxaMn2uqLeFeP5096Mu6wbcngSjroYS/l/x72+CX3sILvaOvt3vYHypvQlPdRbqTTip2OKAqFGoca71QLxu2ihiPMqiMx2VlU7Nq3QzNe6wVHPmMG3bX4z991tWgk0lQXBASBamqOkhM7ngMESZrIZm3rwB88tt1aRNgz3rBnzm3oi5AJyd4YuWYvYt8AOkj5H1AsFQIETBLHapW0RBILvqn06O3OJoMJnGNxVXH/9S6fkLe4qS5SHTnzJq3aceG2siGNdO3ptPEIav2rSrsoezoWxhpsNnJGNujTW7BdHdfvJ1cknz9kjFy7KGXcDdZvhGVBC6GcGgstwFiL9qvLZASrmoT9wXk3gycf5B2wS6Z6fN3WFsQAkUVEJlAdwBZ16P2JRKEAOV9toJlFOKDDvLf5W5dqfLr41P6gR9SDEiqvjVK2iHInnaHPvE2RIbvt0+Q4nIlIWv633u2IPJi1peFM5MMmCA9vlMi6k2IRZiXzxxKaJHUM52CjKGKbcSsc5j/PscSd13llXlveGshMo1mqtlGMaN1qDnLbkvZ51OfLWIDOQ4rz5UiTybswFy5QiasUIppvo6qHjKxxY/MrnRqfsoUYz8vWzbrZC2vPur41StyUAHOHShiEm2dwRUzUq27Jpk5DSshHhMqrSJTSo5sC752ZSmyUqmFNhaNtru9vE3CVFIaLxT9WY3o+nuO2Ju21RUMH4fjI7oZ9McnzI0iotZOMITBjHtwP559q1a+kh05fKjKyNGh6bg5t1YDtWPetP0mAboer9fZrg23w0JWs2KFHapW0Q3PNh1uM5qkoliuImxse90FCKz4qKhjGA/Wlcny/iL/o43u8+SmiqxAiOtu4JXp//iaSGyTd+v51l/XdrMoIEbHcxywW1OXJyREXpRV7zzaED8XmDcIdrgfsM6p8Aa8uEi2lh5fUdRsuiCwzEefbOJCcWeg3NSnnAtGCvEkxwp1mP6kvEi+9z/iX1FSIz+mFFawd6t9SmdW8p2cDvLwqBEZ+ky8vnQ7kFlsnShAVrfq4p36SwrmCNVDTJIXKjy5Kqpm1KpQr0eQCjGuYSW7LRylNk09ZzApIq1YSIuRRdBIZ8cKEFVwMMHVM8IubewTyEyw5J5vncLIUFwIXZFbplm7xSz8oLwr7+H/cBk4hln5QQWgbsNu+IQ0gu+qfY1StoiCQXfVPsapW0RBILvqcAA/v+xVAbS+JqeoTwnGA9hvc5dH+RgoJwmHHU74u3c21NhtrhqRBK9jVBoou5d+g7zgVKGI7ScRFpBixpNjQVa8W8GmDow0JX8pthX581ATtpT2XcqNekMJNqLDFWUursJBfbnOg2XI2P0bdkP/sA3COX2Q8XACnAV8lAixT9COuVnD3f758PGWM8Gd4KKpoSLuBwezGPJGiFuAY3XuBc0Ou50C/SSpTqlH5yMH0WGr5SDrRqnRef24KJm34n1vSvGPj8gbBXmPLPL8ZoY5WrGWx8yUj9W+LS34aAcQ4a/3gDTGtQ9hSa3kdfGt8aTrk/875EPLwoIGujQGkn2wurBnJiTREPunGKOqmVHDqC/la5wQ1QEr59RyIzUSz9h4IJ7dqk4+teY+c6bgcls3teFRMIGrRoDv4d4i3+FVnrcitDJGrift7ak9TDC2kp92n0cTe0TPP+An3TE3fAXgcPWoSHbMycJZumODu3nlwk+1/700o5SMlUEZtCF+2mmuVWGM2nYC5TEpjqkw5WugcjosssNam8kUzKdK+rCEVcotbVixDLEjW0dfaVBjyj17K8t0/dogHW+0Rp0UWigydJtFo5jBo3/iDgxBSHKFByE+T7ceXDtHRx+aVGbJVknGe2ACEg3hQHidFGWPwGIvDioIVWrGV+cwSOxTBGb4szMHdj517MVTz7DuyqrudGV1UzkaqMtdLnXtkjXY2XpDmkMCSwYP933UjjaH4bjLlKHUTAn9WCK+IP29gechK+neNv6SC8JoZlBfOAExOQJzQXoG64vhOe2q3njnZG56b+z3oy1zADrXEAmp5aZhwsP5QiI3KK1RT93vFx+nNwWHKdBIbW//Bc4Z6zBP7CRbke/E7LWtflybWL+O7uR9cxZ92B+L1UzrnnEAKsHdXR19H6AQTxMG3q9bqydKeX+L8i0eOZ27jBX5eOHqOezzwLxvZder6yqEz48E1ZHNQk6TG3R26ECrlHEMvRbPUXobIlrpVFYl13Cqdya2sY4lIbjw5EwEgYL2Nyke9ttQTT7K4EsFUI6AN1IYdWQr6t+Tlvl/J4Sq1JUjea6jghFeGDPATGJUAXRQ5aObAw1xofYT6YmZSg9YEFJVgiBcJ1NWGMeWLoeqlTiM1xtVfSDaJilBJpifq5cakVmTCZB3Fda2F5uSbB0mRHTUUsqSMNkXVRwQ/s93VzmSej1QRTlm0MBSpOya35UEMOwP1AneW67fBy9Yr5nw7RPsT81VO/xg2rKX6RJMDeMy5uwRL+BZro1GVBTf9w3VIYTfrS8SdwLSwbkp2LgdIft+jtspLY4Q83LHWA7jZnxdCQgRylz2rFj6aveNXAJh+tUKMrhXtkWhgzfvqbOWpWuRrqMlNFDjTXFCsQEFfQlB7Ko/cDXeqhJ8q6xf+lbIaa6OqHRTcfF+H9I9MXWkXjFIVm4NycjmVlbauywLi0smp8c2p0AkZB7LApw37dpoIZ20V7KqOH+8gWOUrKY7D79mrEHnl8LNLIfloYTtKVnj50HrFpegi3izzpTeBD6VO3HafCKHTqq8V9r0QKpcKffULzOx2MOTkgBJTxqk+zxHlPYasqVrlfoupGP/l6WVrTGFtx3Q5IdC+iqGCBmujN6mHt8VoPLJpN5rq8/bhGUTu6NSY97vp/SEeGPBXQPookG2NOQz/YAhd45r9LP5EV4OI/YfTv/V2XK99HH3qyUJx83HuC1RYb/WdlhmValahjTdB3ithrClGyXI0rKKrvf0DL9XkIiJtym+OvCmvw0Z2HGEC/Ab8xHorZR+AUzuMhDJR5fQtuDxma8e6BJSDCve9/u+KhRhadnwFOlIuwpoEQm4Asus/seoh5L1avapJ4T5NPLhf30ZIuav+rKeGbapywCHb7gv0p5vv3ktmZLBoDK/dWkzry4i8rvqmPcXVA2YNfScuSD31OCC2lCcZ1byBFBnPSsjbDYn1wZm3W/tTvsjPsgw0PpfkAjxfCnxfTCKHwoGiEC7fOtpDvEC3FjKTjfPhe3p8XBtV3dnGy0v278x5LNdy7qqgTYNl9yXFHBI/MGKibzJROERCddCKD6z1AK0mZyyffbIi6HH8/jma8y1RqQBrskFd5MVCj/+vxEZaKvt2JYPxqFMghg2UKYA72JorZ+3UtvC+Vs5b5tj9cF9ojLNyuawrIhSNbfTXJsNplmFtkJzvluajR3TCNZenmxvQ6Y9pUKm6o99PlLFjlz1OlWJ+A4iviiMWoVKhSVGsKVNDibFw1HSBv48vE3gN6wFKGFeq7Nld8KC1wUSIMFQmV94R2Euq7EA8g2/qf/NBhYxLx4yJ41ZB9jMSXAUAaps1Urmx/TSWOvlCgWOnNVFKM5Ssbeucd9Nmvl92X9SZwdbeIR5JHhA82zdZdk6fxXQLd/Z0eeWbVAzbH5jbWKN/uK9KOaGWfTHehVfqLLdM8oDt7mpsh1zaq62Pd1nxttQsiw+HKYJGG0slT84a/A+7rFX/lZxqbexsCusthcl430lBhI4t8dMrtYmcwAVtoUOt9/nuEUKJDchTVrPoUIapygzijEvV1k60S6uy4Ucu7CvYyhb6AwjPb4waWzfU9QkKBbcS6dB9WjcYUap/wlRQZ9qUhr6e6gmVwsFfrQGoh9Ve1+aoUCkx9J0igVWoruUP7phOI57bKHodNq62utSh6vrLFlHaYXUJRoOzzyY9uOqT29jHxipEzDttwsWVBj/ExtVCHUy64qDEgztq1IHLfW6mSQZyHPXGB6/bGdrHg5HNviVFv7C1Rxspu8BmzUeGPwsLkl2YyiiDjxW4QXDiSMD4eC4M8/1ZKoiPi/PJhvdlDJoNA23aW3SCWm4HaMshYbAAMeTipz5cxcHC5qZGWt6OLz7Roq/rkqZXwVOzIDbLmi58XAP5Lu9XaG8qnAEhKOTN2fXSDt6fWGYXkKudATpJtWH2KPLYzqMtU5nyr2kwaMRNtKAdDV89cyA9fwUz4P6BPSrm745sORH8wch5AU2pd27UnXg+hzaD9inFDpTBcG1TrM0VceIOUE4bjTjyZkNz5cljLRVLQ6aNGTMMs/IJp6RWfvsd2j7BWmJtDyqEX6E6E0xOszDojS0BCROAyV73XYCPh6OQcmdOw/fQ3E/I3XXlj7JYQmBmkT39QTYJldJ7ssBuQ8GNvee2YXecFUjLf2Odi7SqFydXWUKwZmzs5rwP8OVRhNNln/3aSrqtU9laPFIsHah1FFR3hk0WD3wvZAxrel3hN0nWal7vcvu/ycFtMPalysFqcM6JPSrA1LN1QxCEsuJnwMxhvVvIpz90cZqvPkewLG5wXfm89Wjvc9XALXNW3bHFp+Kr3DnP4L8bhz4JIXnI7pXGYLBm+aX/y4MFlNN8c+DgVevz/IC9nkNy+DsCQPcJgMj7uQQ8aZxQPl3zI+N4UA/T9ooM5RjGRhO4efP/8Schr5FN3lzAsXB6AMgEdpDmAKHZJ+VLWknLVMiY8kNY5k5DISesIDsgu7uzSLsX85nngCSDY4mqDGjErIELSREIg0Q6nVKw2QncjKUHjpvarYQhfUQUL7ziP8bUuqtMAPHijSgVlnpHyKnNqOqMA6gbiJgVF8qgN7ATkr3fPE9TtyB/q24aWDxa9VtwqwoqgGrrV4TfJRr9mDSsOQFEpuLIOv8IGE57zjSMa8FcM+AID/YyjOk4RlOlp7qSDePBpfwI/0AX6xADUjLt5M5g/JOXC/l37JNBpxpcvSFiimcZ+eB6BFrkVd/eK4ssVBvUDMLEm6sVh6icwpPye2KK2L1E/YTYwtnpCyUvcsw8NnKMHCUI8ZzV4D8fNzntcp/SN66p4JpHBiW0bGIjYiZehta+/UyVmjHysj2j9yr0myDF9LCQsTq+i9kcdQDmC9QhVsmRtjSVRJdIXHubb6xOhxoAi+hQ06BAgyUu7Kf/KqDpgZdueSXZb9PBWtkwDbJ8cXEsBRPRj4/zKBtcZlDqY2y/+vPTW5STcP/cAnHM0fQCUfbjVIQY1cQ+8nwaRzmGmyhjA7RPBQHteQy4UwXpYY51NMmRADN8XHC8EWWcdwsLNRHoFHBwRAd2AKzOOE3nxAxeLjdfC4dkfLhUWYoF43i8kzjBLA5Zb6tyoy63R8CM2NcarldnAFw6RegYfwtjievBEMlGgksqe9ykK8v+qcA/CaHFd0wLFDb2WcZRbfXrZTuETiJbNqJUFWAXgU4g90RIiSrjKZrsW2aeq6otk2vAfZoQSzJjgjPi1O/3pJaBx/TChT1yNVVjicx+GGxNINbROCN0imV16schXyBa2TDe7CdKf5xK0NNiYdbfm/XF97SMUdOoxs0B5lY3zWtQIQu/a4rsRDA2zCxvvP5mJMOZEnCKNfm5G48NGOkQe2WF7IAqMX3Il14RZGKNk/6oNR0j/oP971EenyHzzy6wMa03gmlOaes00YObutYD3VCKWPCgTlnMJY+UV7TRXEgZ1aO6DKJduZL5YjeSY5oROgYQiPhZWVDalR+pXPUIQJMETAQ013wyXbMj9rSPQrCQFVPJNun8oGfCa0994zCqdeX1F1yMQa6F+OAhhpu5uftij/DDSaTqf5OVy20sl8RM7PDPtytlGtSdjgpow0ugS8Dgwz0U7Tg1xrHiG93D4G3+zsOzWJDoisEIDcF6XuECG4ljHpxu52DVqk2JCCxCsC8lkZsNx4uuS56d2EXrtqJk/NlKWmmi6BE24TQ7RNdFuigY8Yr9bPkgI9UgXew/qqfNqDSfGmsTX3fO4FEgieoujPhDiWqCQx1h0e0uFPoe9m30HgQGJm1tpFDWEzQBgF4ucEwI1eczGNZZem/bZin2lXCzbE1WzLeziJf69ESxSdhn3fHRpE3k1TX7cbFw4c70ZdbKB8iHsUKBWAYNFKSJtjE/0JS+mINtzLBaUkvNJeoBjfBVEngBN/j72E66oJwAUL9BXVWWg6N79SQKGkkbzjaBJ6bHtMdkkEWhYtc3NbbVJGepECzl0vT9tvM2VS7FiSZ3gRLaPKMRl5ymHg62hVLQNB2MIVZE2mH4vhk4cJylaZQhAyGwL/XQsIhWD2sNV14R6jITtEMc93eKlfQJilqG4qqLrBCvtKT7Od/nNNBJajzCwVzgv7c5TSKSftoaiDjqqmaQN4L+RqzQRMdMfPGBtCDpEPNz5lJ3AufmHn2Ql+z6r2hf+6tmlUIwO7gBms/40jlmnR/JLq73e/OJqEX3J4RGu+mqJzWgesenTK0II4Flggpe+7Mdt4aVM7pLXBtj4AYB4vJLUeAR1uOOm/2c2YcbneXDvOF9rYPvWgsr50RpUEGLNXcO+MLDtX6OJIhE+VFQbG9DxZov4pW8TxW0KEs2k1+m+wWk+wi+0cC2l+/gNufqb2xLuM3H9nCcCRsSEcsZfgo4VTn+vb6VDsElkqQ/NGfWQQpnY4btxCb3ok/c7V8R9bnHwtj1f6C7n3l/yMfDFcI0kydaDXdpIHsjJn+NiO0GD2bb80X+C60CpqjBGWIoMCrakRwEIAXLjUU/iLNy3pkRbAJVhhA34YxtbjX4jBEsCF+wetAAUwZMoRTwy0GByhTZzRx8KVi3Bejsh426cZ31hhp45c+ik8c81UqWjrj9tq92B+f5TE32uUs5R/5pN0UmnyxwPo0TFouYgqLG0wppQOt/VzLM7RP++wpZWVUX2nszeskuOis7jVQF+cY/LMbx6Ix61Pfh/VJ6K503mRFAZLjFgG8/LTlFxUYUayPul+HLgVbb2KqZZTQeGijacclpV/Typ6UZ0XBsIYXdsKNY7Bt+xJYfSW+j7JNQG0Vm5J+V12ExFtgnO8Tu5P05YkCzx4gBn/A529bqUleL8nX9FvlSYEqfqM7JdHLbfyjMZGKhexKkMaWDxaFV56sRg9W4l01NmWMU/EkZVhigi5X6YFpxNwq0U9W6pk5m6Z1FcAz0duG2G+XbTHcVQjYpXrnNoHfApsFMZRByg6QMENF2/+pC897Q+uccab5Pzzw/LD/c2TKq+aDnRgUiRkCI9R1oRgDxkzHILQ+LeMSL0Eg65RWF8kqNqld0JTngnZN9RRZVN+UagVZPfYO1RtKDlYNHCRe4A5PUtWT3geD39EXX0chNvZRRKD4liOu/CdLPDQ6Zgldvgegl96nEb3f0ny8YmOSvgoHHvJygWwtQuvLB7qCs2CvrrMVvOeSeKK1icXN7l2e0QFhZMsZW0BcguGJ2S2+lNpvs3VUU8MJ40G4djo83TKCZOBsEQSzrFHJODXBZ6YXh41Zc761CIywYZJYoHFqboBCh8Nv43rM9pLFkprhfMmaUxYLdvILTVQBAzQlBWSPDAcTEYUOyZbbPuxVveaSBBs1aImgnKim+iMQ252nYPIZeoPoFb9Fev90NmoyqzKZjfVGyqVZTLETchCmRL/2q6KdmrfJtoHvYiZY6g2OozQb4jsEb2cFeiKPakkvHQqHvQ3vYytq+E7HhRWXYIrTtkYNmhrnEq4lFmCK+lAFGR12aQSHx5KLiK9efLMVFUZWtV5FmwYGkTzzhMmQ74iZ+z7HfkOYUJWaaSMshuvvoBEA2Yh72MxslPa6/Dh8fgyvMan2CRoLg1nHA4pxexJtXSppLecsOi1xRtfow85cVHOHGJDpMLP2CUWmuiVuSApQDmkGWhOvU2t6xQWTgEAUrHDlxMLP+hZqnsswSRytQFmHKYf2efe/fyszcn3bjQYywfr6wFJN4gdjK22cCqymESljfvPunzfm0kZxfRnZFp+/kx3Y6eexn7Pq58PEtPs6kYBBVd1n8nYJsBkcSt0VHdFVRh40gUDda6kKpIL8B+PL7oYCKYMiQFvsPeItK1s0xjO/YcELQJdGZl4aTOnLuwdmOLBlF6TDqKxQkNuPAbrskDFtwmsWtbY6e/UwIlKOkOv3Voy1tS8Q9TSxuv7mBovVpub7KfauheYo5oE3cnNOWcWmk07YOpMXIq4dLJKBbc1JiaTeYMAlR0Nwz7oKyV4vqeqzlhi1Q7cELWpyOumFZ49cME+K2t9hRBZFQQfBd5mvtyciJxsWfqAahWf8dwMdvfLAAsng3s2PCW1MsNoWqcecBsp9ppSFpUduHzt9LJMilo1JeDTuHXUdVFuCKwOvkYdx2jp2uz/RQE9F4DeDqMQDl3molTmq8yEyR+IgDKeZ7OfzHm5KOSP1Q0BlIOExkML0UodLheDeZzXPc5WLMwJ+f+HS9N5x+TDBqrYfjVfl3hPwWG08ZMbpMJ9ORbbM3FVT3uVFizvm0cHG8jEHx3UjzJcl5r+YVOejMRXxtMToSHJLAcfOWd2WjIKe+VBXlbcrAQLNL51qZNxuv802tVAqdSqfug/CjUfgC/c52Gq+CuIGP+K2u1uUnQHEFO3LFgltLei+LrLL0AGR2sguB6QY2f2xStwYVpmxx+50f7AoYOzBgXijivaRkCUc24jy3n0KeJ59SmspavI3IAzY/tou9qXTcye+S3xjtOr+5rJDJ1pl4iK7akIJe0b8ATmAJ8/NZ+ZLvE/9NI8JCG4Xn0dVyTmPVpx0YUsAQ9S69yIFwUf5Yh2ePw0FEDclU67XfLtLeLChbZPkm7QpwFkczW3JUhwxamscYeyKrB2LrzzBTgNCjxesmSTW5zdP2h44UG+o4Xa2K8uymF4A6OcVVRY6xhII0ZXo+p0UBS28mZAZQf3xlu57bChUxC5fCmCHUKZ0C9IMYhNMe3kqnotLNILRlCqpUFV6DFY8QxyXvHVcTOQXmVIr5ZlYdZf4PNcZISD9jsaQVzayg9rZr07Fpo5hD8xaYCzlnKkAlPCLkO+6yh10hZadr562/FfU5918Ung8Mlfyi7VWUXArvaj0XYggB3W9GvhCcEF/tI6Fn2p0I8ZomR+yWOh0lkCZQXbJWCE5SG3H3at3mwGXnA8gCfs786uXJGU7YLMn0gAc7hGx4vrpB/BjySRV+ul7t+taJlowBq01lVz5v8mG+Mq0LGOWzs9TmoojQZn7PjqfVYzYf4sktrnTVi3ztseDM/gqOd43GOIwn42cn2gSzc7tnZJQlYyEw0kxKXmmtR+V7Z3hNf8L0ttVPOFbP+v1g7sFCnnerW9lnlSfEvOogUuOFXpiSLcX33nHd61Z8rLeSU3S+cT5Jci5hhiAOi28lxjYjtKtp9bsqwyiUUAnt6E9+qzF92PyMw1/0ROVujXAC4ZRTQbVMUT2JQuGpUJnEGhMmXVt0UD8fh5aZadcEoCO/j5SRDycZJeJ0TRa1t+37PA1w8eBhEutI4rLI4/Z2s9wl2cpegw7PRcvw4g4aPelWpeezTh3NbTGjV0g35VQVQ3KsCwX3zLmPMkoZ6KeoyC6hso1pl9dIeEAPYECwieDv/DvV2/aeKYinsCqxXCibQC7lzdS6AYzkQT/yH2At2OVup+OruDJDALlmlvhNveLh3gSHOpvHhZ0M7mzGS6awCcfM0v+LJMzPsNa6cU7MOjSbCulrsTOfH2A/Y4XH3rpp5AcWNhg/S8VLPhOqB5inc+6Hz+VIDIgDUqSCh2POQOVehvYl5fYsIYNWoHYAcwUs+nv/EoeK4GAZph2/gUH/Sa39ElEcNxK/Qk1MKEGH946T+JvKvj5nJUkOX1kUkf5AZ5UZlYANYevqJNKnHgGCzgXPp4LB+U5QA4dkl5l/yqq6orSaJXupVbDSXl75ShKJclV/zus7Ev41W78SIF52Oc6c7ucIJk1kaR/nI0iOn2Y2g26U52k6cqcVy5OadpFRUal44/AHxwvs9mm+bUhr28rOsnjwSh7RkhR6xH4hKH0iG0LAInZBEEqRvY5bmryFo7BiuRJlqdvLCzLj68viTCVEb9DuYydNFgxhGJIT/42JAIa4qya/KIeGY0fgNtFLJ/iY5wTwbj7oJg1VmSg2Ium9xDm90liOR1fcyAkbOVowmN/cOW9DVJge2DQBCa3gqjiAGLKxJRPzS+E3vQKWXmp9HWi9hvbBZ2unrdKE6trMsoOS4J33/d0ArN9/BFMtvA6IXPVNdz17W4Q7hvFJKtHbC1b2Hqcm+feN5mKqyZKgdNiteW7l8tY92oXZD5/Rku48w0T0ZI+XfvlrmU7xId9jW+RGClUUZa2mTDMtrfAO0M3f/NSncdcck56BuSO0jZbFJiu0jBSUUQxHamokCJ2EXFQ2GQhlTmGPJdYL1Bwdnpp0CbygmFO3nQBjNwAcIY00heA8csASRliobhD/5LehHmdqT/OM7dpOpyK73fqhfvxRMgJtOyWU9WpIfjqRG6pjuk4NuAXb31adKF+H9cb4pg+5tyjwF1WTZhM4RfC0ZvZUNMmfg8jM1Cx55Jqo0sVrD2sZOuX5JxW77DgImR4six1J1l4A+g7abhAW5ws6F1zrAB5NU0GySgAC0gfcc/2PO5PnWzTXgb51g/wqhCfps/aAbYs23ELu8FjwqBojePyIJym3nOcixLA26+Ng3xu1zm67qm00RqM4VkakBvu7biIhlp3uoI537cMEO0rmqjxJuVcEIZoRQi40/dZ21fqrzXWWkwIVPJot0nCeQOaCS8V3ZBHZOUXflUV82mhTV7Sk/3ls1uLXhuzhUqcPNQde2JKV0Jgh+xglS1Wo1SPxPjlhAm5ZohoACcGZcm3q/npYBrdzauGbCcXJ0rZr2MS9ZJTXLPfGqRneFU20ZveSTFnLH80BuEEXWkulhrLWREEfKhEghLd9Ej7IooCEAN0onhOsPcWHWAn6ofnSU3RO2kAfxMXLCBMimioQPiP4Sy6q7DY1BVjMRmn2HIAY2MxiFtu7ZQee2pNVUyosynI2cLOrSxah8F1gmWou6Tolfgy+kWXlPXmKTAfS8/HmCyt4EM0CJh1VwcKCoP82gjn+j0t9eR8YqlGvjRyoZ2wqF+SeepZhQh6I/aBBIZFQI/Rw0gCRlz5Lz4A6FsdpKOZfb083DMSLfgtu9W7lZ86ypkfhijZx9TRgGJQ/4wPTQhdldNRgIusuRQeNXKoSwt5XZNMov1HNCn6dwLswhnxS6xBRK7h6US1KvMGIl7MHp9EJw+tSLyy1GF8qLl4yTqEiUo3TssLCx7w+JcpJcPuXl9EdB8SuPB9jQ4COKCcqNIujbOTp5OSohzHjGsEhAqmvvy2h2/sR7vDXIRafne1EXofmyLiitPurpH3NyTy3r/ricqO/OVayqSFPDf0TmHbPjaBnOdi+Xq8gshrS0tS8eRhFNlVl0VXOIaUFoei3AeyAn+5f9NxPZWltLfKyV9ZEy7GuM/B6+J69jOMrUxb6F4KLz0ejV/3iaEbLjsIeegK8vWR5+XMDsM8D4xyHSEY61AH6lZ9o0ZtQn43IN1dGHz2x9SlDrKFugot94mYynz5CWFGizV9dJxuZhYYuRY8kA291dKE2Vch1jMSkTEfbXCSZ6aYriKTDR4eVruCYU7YJ4J5b8FlsXElvH1NakA4/UFm4BlxYJatvxxWqaw0XLhttSahH6ZcmRxY4sWJ0Jnvh8pxW1/SlV5JC4r5lBp+XeznCQwdzamrsxGtLSJAaCgziroZZ6vX3vhVVVo+xYRDn4R8Ywbgxs8cKy0VBEfTPtYR1LiomXnGjpmq93EQHBPKreM13Mej9aFlDuCjnfaRwsLAJTuqNQ1EmNVdqAHQlSUpG1OJFGBUUZjQG9XVc8oXv1hpoYZnR4afQOrmd4EIyTwv46q+EzufZ98RQAsqzh580Vmj/7+H9BlBFOPCvzksKDHYXFne2q3G7c7lbdTv1mf8efeEGFtHX5jQkITqJrwbq12REo2d6LRFpkNv7mvLrdu7VXjISvfESkDgbqTYBoooaS9slWa64CNww3TXtMLSnQXHOYTWdItcBaK56wszMDAc3zbpx86Vwanxs6djJf8ZlT30oTrCJtJcZOJc2ytkQSr1lQE+XcBjYu/OGRgjYEs94EaA56Qu4Uw+DAyqoRK/T1cl7LnqYsiAda5LzUVOsvI21/e80U2QTjBJ5xSGiuhiXCi393bUegMj/mlyv1iBo4X1HHq+G+zhJqitmd3ttBr1Gej6WQdoTfePX6GY1crKTEVieo2Tc8xUaisEdmgO8j85wO467MDDufINYppEONq1rlHXDC1wWSmUW7qJrKEYLN6wZn9RsACMPdmNgPl/FDI/dCRSETcPyLzL2dD+IKt63SVebfSogfl+BBT5UzKXdlnfJjWMpspjh0fL3FeQ/T6Hi+NnXyivaIYLeBA570KD8+oMSmc1wPnR79oTmIXIxH40hK3J4QBpSKKY3WyFGcvHPv4ioRg8JwUhe6LtdBPlZuVsBMCnU2N5mBTn1xR6R3pjIVljCRewngVZULUoQX6MSA6Gt07AUqcz7/LRvHmflT+3dpr/StvAt4YAkgmU2xueBHMlBRW5/dLLMIkXFXTDDAQxfNJLQc+/M8fCdfDBVyOAzOd/sb0D0/x8GdBQIjpNa872qujF1nu7h/T+pUH/vJ+HRNNmzLfDH4dudM0zCp7p4vN1TkqwmKTMTTSuBansKRRmUMxPk2qRrXcLPEsElmZLFVI5+b62djyKkqp7IXHtE1WzfXrjPrT3LYDzs5LVWQp8ZIIt3OOwaW/dC99Uqh1Zei91IpYnytGUOYovFuI8kC703qeFJ8ufQPqt4xE5+Z9LnPT2lK3WWTZyrXhq5P4oyIBVlHgCh+bX6lOAqyq3lnrJW+KFAYYUxGAeWoK8Ne+95dhshqEvFkOvo+4eYCLTch+14CZGA4HWn0snynSOS19ooJ13+rOcDMezXRGZ8G5D+P5NE5CSCIEvvctkva1gaAItDH6wemItk8OCUi2pd6rG7yIw6vuDHw6ug/VDD+9r8EeSFW62ASsIuexTlO83FUqlVEw3z5pQqcQF98CQ68Q9hNs+a5pobZBrBUBhCc4tSpWQlITSKVYWuYVdAP0e54N/7bg3O7gFz46/kLQMva7OiAeD/E8idtOCWHpmHpgGTcm/XxldZR2+b1cCSn+VWPC5qGudj7DM2PppsEFv55d5cb6iSEQnY7hM//KrMNmb83O/oj8JvSGJG5zw1fvYb0850ZzREyVFkLvOs1uo0g7F5bQnwwkxDUOF3e/lOfrsbmeo8zLavD+GbFnaEMBUUwKaDClhqGg52MPmOXak8Vg2fw39BZCR3WxDdFtd5Z3XaVDTaCIKu32VeGs1N4EfTvYdck9eIO4jgzI9eViOIU85/xFq4lXqHIe962nxpgRmM1W48G8vHNTlkaVB1ypDwU6jjW/6oXNJtMS41fz57Jr67HTNmAgjNNGmyPW+E9n/OuxkWT8qR89opviQHGtjQDk5NDK99nhFg32Z48tCNv2EJ8Ch6Gfnl+lQyWPfxuVL4oj7KeFctR0JbBYKZsqDfpOdu64tHhVVv/bdkGkAHKZ3DitJiBzo1w8GTh5uDJSS0124uIOy5/l3YTSeMLPgGX7in/A2C8Eqp7QUitgKv6pu7gvXqGJEuo/NKAQSYtmPONCiCTAYGTuOVUCfizPKHb0xqwHV0g8jP2+1vX8ytdoe+WpwOUwzGVorcMGTQf3r1qhRnr0txET3YJmi3Ft1Lmhqh+8gdnBNKY4QxlspqEAAP2+zedzL32L+KQJwiFLGM/TdLSLiTK9CEXsR+mm1Fnz2PsPLD23TSNs6t5BoGCs/lVN2c/u89ZqfwQlvTj3uks3MrFH0ou3O/eZXXobIcR3PC5X99JVDUqzrtHGCGd40vXw3soiPAWz3ZEPHhrcihfIE04xA+b/KKnzvOFWf7gOOldINWWjd/LssD6goKvsIspYVx8cB0YKbCIRQhzJn0mJLErCPA+en6cCwbqSUKy/PutnE4cBU+Q0Q8W7AdgF3ME+ozzUeuH36hfqugtMeQPaVpRYrVYAuEixHmsiz9lA3n26EBqIHZ2JY8fM7Zw+W1hwvaqKMZ0CXmvmYER+waFwS38byCYtN/Ntd2qLa1v0FX5Akv57Q9nHGYOkmpCnJYitiZJbngLFNIaPK9/CUeMaj3Mm6W7HG4GVllm0wJUClib9XlDe1pEveJC4520zztrnBJ/vzzZmTOcNM1e+HOTC7w9ION9a4gyObokV6PsvHot+/EzH9a0ykQC3f7mrscRFlOtUutoablG3YOFo+IwXvLq5HUyrLv7wY1YLc3H8dPtvDMoernxFmeNOqFVVnT+AWkdLpGyrbPhdnmgt6gLtw79UlGJcWYS82RZqGzoMLEqqqwx6eKOV9UTqhT711WgNuSO5LwNj8UguILgICBG3EGVgxUd/uNSuE28+MxXOcssLsBUB9K6NrROhDZkd2qC/6/G1jTXy3mSAlt6BHubJHuSEuwMY4zna6uGozZnCq192fl0aKKt6L4RXRVb5vTFdm5Bx8ay25IQWyjinU0++NhJPqp+CkPNTZdJZmxziH+mcFgql52GVSoTo2SFLsNmkAyFavHZc1cWxGKtIlLC7Ko1lSDqdXSuEIOjMgNl8caLTCi4AviSCi7Fi5Cq8cLDopmghw+hiG4H3OfDOIHyxA7kqHr6KC5qhoTH7HS0iOFUulZjhVvxiRBjdAynrevSrZgcNPp49m+86AsJhUhETXHxatFLomcAk/osivdImOKmttZWndRh5ev1/odo8w0rmtouruLrj3142RgqB4abPmkkLn5M4Ofr4aSQuhcxw5lK2PCvulEhGhzrDiFfkvE4ZXR3hDsibBcDDc1MUKmcjAaj9uSlsZhZUfwlHEy2fmks9IBXYa8poTfYI93SIp/OrgZPj8ZBFpgBaI7NOq8iFr/bZ3I9MbGhYzPy/e7rAANTiC+Mu8uVmyJ0Se8h5hHlMH2gDxxaXs3XfU4NtbNa7W822YU+WnsL27YHjBuntvFFn5kfgCVEn6HZUUTwiJBYr/Y239VIUlGqv1npiusYYWzpqQVlwNnKjWpoP0xMSJqiMHNVS9HQoHTKdMQGP1utvUVm5lVzLO1hjzDz+Rv/AEZgb5XmPBlj5NSkba1Ps+FeGFkosi1a67H6BoTetSzbs/Z+bDiGGdtsWtCnmNj3mcNFX/IAaBZDLTePku5esuxOPovfGQ7VYdFQRHZJDrSje4ZgOatSI3uMDUaKepZjnVMsYAHuK2H0SK2wXv946m6z/jlxE0BJgHwvcZGPhZ//Ct/zNCnlb7f5FOYVv0FsEOtQpbybMgrvCdxwV5ANMMUITjBA8JZjRW4GpEE9n0Awv5QkJzjA8c6WqOwwH0o7NZWwdppp7pg8DhBWX7KA6SSlVX4ccCLe4Fiw6Vo9e/23ERR/81ww0Pnsy/j71fwKkK52WSTJXlhtIGTx+Fr/J2Czxa1nCMpkgAX20qtYkyk+aZX+p5St6c5bLGBu7AffAJkuNOmBgVXMmSJgNMXbIZlXcIX6q1xvLteyRs0Tn37RhCNUegODeK3bXm8UcX4WhScOojCMKc06IJgO4fEN8vbtVuzNMibOv6xbhq0E6j8EdqySa56y+ZivOH5ZwU6IHQ5l7FP1FUgC7QcRVgTb1MNLXqdZv41hb8GuWhYkGwW6uErZ4+RSrAf/lazxqTzhfHjPejc8QZjvL184CUNINcd0mGmv5uoN+qlCd2sDR6uq+hPfnPPztt6ITN2fl0aeUDLTksj7kZRgoZLG7H2xEPNnKQWpU4vGOEVK0c3pos+sk9/M0jIj8mtcHofOlWfnf65jnychvxI1RpsLRgRPmz4neYv76iKBLYq9b/RmCZGv39wICWWHfD8GsoJBUXBpXIlqiwn8cYkbIkiAZJF9EwgAqHdvqqwUV7Z/JQPX0GiexQJJp+rH39ATb6xwMIc3Ti1CuEd2G0GZuBS3f5nI97oIY/4qAw+2QMsuYyunCV/v6vBR13QpDcWWK7FStjm9itmynzLHZGYZOYV88EXgsos3ViXWCttQN7VzRJWN8/ytCHs5MuOdjsj8Ua7HZ6+0noGZGnw/hdb2rZ1xnAr3F64zQQqlfMz+pJIBLmtuluFVso9HO86bXz1XFAkc0P51ZJvt8s8LKirPb4YHe26mUU7qdS5M0PAkuZJbiMYLscrmT+zTQlLgy7qwHnyi1lRXSFAWkRm7Zwit2tXYGBK/LMa/7UJx5K1653m6g2X1FmWq4119W1XXDEOyb2ubPmLUbaToZ1o972R5qFamWbGLdxugYbWOIeFYNCsj4A6r6+Ve9JN+VElZVkfRw8w6M11j+Nutb4F5NqSZPxynk/Aw/ODbSq3cq4lgz6WL4dsMcgc7MBOSkwdAJeSt/z1kBcldyFxVOtbDsm2hn+fDaTHd58uGYPG39YoOVlnRBe0U1B/i7DnGm9ixrE3bS+FxU8RVvrdZTzZXZX5S7C48kEI5fxvljB51YnrNYzFC1gsVS24Dphcag9qvVtJ/MPeilRODbX4C/3pmkOjX5Kcy/5NvuDE9Mh6YLAfhgMoFk0MpRNhfk+U3fxXhccUfhidx0c95+1f/1iLLyE3HUDa28a7MCMfEsiuC0H8icY91/fMYOQyxiDOQdkyI5VChwpACXUSWA/bu8rI+KAnulWACp8QTR93qgk/mQPJrSx6NaLxga8aGsh4qjgk/3Kf+js37sBApDBTjdSqmGAwkM7Bzs8bKSbW8V88n9AnTyhOpMo7Pxqt2yAIfqfBl+qyofUFQIHL/lSboRVaCzmHEgg/gERVkiuNNkxrJskJRYqpVITXs4NchLbtc3rp9a+v82d1UDEdGmGMhZVXEtjBFGC9EiOqMMwPviRgH4b2j8veEwU0J+pMNgL1CXoe/3vtlmYzkxY4sNoL4Jv+CnNSP7gN2aWjCM0n5xpv7OlJ81wYhLv3ypIMQZBSHUZO9nL0eRRIsP9Dk85E1MRqmmRHn09B6OFkvwZ82entu5JKYlPlbGjKDAy1pwjyLnklHvxX4e1rD0PYG2YoKBRSQuTzvpKqOu87JPiC1vZWOtVtDkQJH0ErjFQqElOmluYgq0zDXxDa7oDhRLV/8Kt6AiOX1z2PCdwRzUBlK12Y5Z+dEH66m+5GwZjwmPELE9uXRIEV8xwEdeEXfV84aeNsIm65NebDcJLFIBbldve7ZYIo+z7U2R1SAxA2vfWZrfrymgJiZaETcWj4NkmvW+W/MyDAnhT7MJFBwdQ3+x+0jZkzNqlvYHmoRmtRjIyk/unFwp5CVadXh3CA6WCOPJD+WoTfNxwURqsVAVQ2ll71z5NF1CEYpZJr2tSqJ5P8WYF39zeSk0Sv5RhD+35oyShjtPOFII70RlTibj7lcAQLzjANd2+/UPoaPCl1XiQDG+2rvzhN3elV3YThHBvuWL5UBZvvAQtIFKQEWrwNzeyPwUFm/6lxChQPZSJqc0LdkBjjy6M9jtyCZ7MUWBGdb3R8st1SpnXfO0i1bsttTHzhJh/cF2a/bdY3IqT9ztLttkNE/xsW70nK78XgsyGkPjbGlBwF4dwPh0HY2M8vyq+h6pHwoZE/mMcK6JC7Aj5+WNRq9UgsWoEeywwXSnfM7R1b3NQ36IwBbpjVtr4KMj0LNg02/OkgewokH8uhiwbJNTk4wnQz6n5CA8yvC7XhynssQt69WyTjiNju5pSh91GW63/1KdkYbsBlxzvx+fs0az50LgOSB7xkXLSw1Vxg1zPV5fMdGwfmJL2czGJrMq1TzLIz+6L766UF+vR1zZUH1Jj0SUNPl8YGXbyz8Y+kcJns+4EH+qI1uruNOzBaPErfpmj/7///ymgx/hXl3ZM7g4O5LP0+FJ7Q32ycoVJ4TvdY9lJJT4FfJ1F+fnSgomym6fQtWRzMburx0ajEJNSDgnApyYZU8pgfPBG3qnDGPHclPm4Zw/kecXOf1Ok7dMrino5Xg9YqSh+PFMqSaT/VRpAmXobhedXb9jj88o3aEC2dVk/R/Rrpi657R+ywEGmM2t1XMHyON93WQYnL7awOWJaagD2gtLmr6YLYDxwG2usfYEGJwEOqjXWUQSjsenqES6vrxmD003c73N/gw7MOTynj9qjsdpzN9Gn2JYQjlvTs1klKEsWeGmiPanWhiVmY3MWDGh1i/OGlye5mZQzGOwQj/yK5B/Zig+Jp8ast89M/A5lm13Tyd3FMK5DE7KGdFrbRYvFtxiemPHtDAC2CKQTvWeTjE2PialVOaifWL5bAadlsNn/B1VyWONsJ3OuVyM2Yxm2eJ42litN5WxAawr0JCp+k8Oxz3odd5KvWeU9uhzhXVYxGH9imOa+4B6HeH2AvHoeaNa6toSZCrxVoBfFAvfos4zjTsf/NKNMHni/FJSEhFpaI7FO8BE0mI2fHWXlBrF+QkVV1B/zrc/QaPThm+6IkVaYs7HWuiwDcAu8X+7WT5oaiDXe0J5IknBCEsTBD0yP6n/paZnOUQSEYt1+d40SeilqJF4dWffH9oEz/hMBNxVI2fVAdLnAg4oC3b4ppnlRIEZ4LnDS450p/V9+S4XoH3zMDBdeq02irw+WbYzt5qwM56zrijwa0Tt8qoopr1q9LerTgLxhlN1FkiuAxnK8Yv1UeqlD0dN/Y2qFz0wreiSTb1wj9zkkBJdnOBIDWmTUvAUzZFsHVfMzazsANsrEHV/xLWUTnhcN/0WUZoPWEsV8C5dfMiCdsRqz4QlchrJR0HbArDSl4WXvbqur8i+ZQ1L5T+XUyb6Xh2xU4KUil+XhGynC5WAPcUc3eJruxXSnB+UWtVzPITi+dKaKJ5KHr6HGgdSc1J1mFUevsdpQx/LK4IzXOTyvielUuVyB9Bh32Gu38QzzpV7vl7MlE2bgRKynGxsbHhOFkrrKock9ya0bbCBpxYcg92fWcV0gJIoNgq+1NONtdh2SoBOa8AO2+4BhTZrabVrzlhvthaKfz4EY73EFEbRhyURLxoBkKMo+d0ey/RgEE+7K8lIB3b7JpWAOlF9UDtf26bC69UVc0dOhZS3fe6JKY2P3/+0IloTgazB1f0SW8NNeoUlsGuq2ASF3iD/FvZkc3m/GvRdi6d84wzdpSh73hxqfXj2DfH3wFuQTvvaeWof0LcWqLQ31pNgO4lbtMPzKjGXvb0+/Hl9XmIVixR6ENu7tgxxYLmYCJpe4/EEbmyD5hMYFtnH8Elp6Muq8/DW85gIgrOmOG3Gr4UeqkBEyA0zQUlrJCqq0rmNaiMPOM1Q8wyPb8c/OWDF3NwygtqipS7WIgafiYCaisjsE/s9PilsQtYXt98NVAgWnOwKN8Hgj5w2DbnlkDJ6UzeiMG67E4RZnA7cDKDDRBaCFMNHFDzqItXssOFAG/0Dip9EOcetJtv2OML6wvp97mGEDiS5XjQXFp0PxIIpyyILyAZOuRcvn99VO3i9AbnHzCfvshB2BdRi0Eds09feMuVyItf645enhRLFEgjiqeNonE8qaZq6ZmOx6tF9LREqh3TA26VPLNQSze1VDnU4LInuCj0zIl0z2ifK74QD26He1HC70MO1wqYAAf1KwGeAIoH2Ty2xabYReIyYJTg4QEFW6nFGjx9LN2Gvf0mNvRERhwJSBYRWZMiN5OOq5WFVZ8lz3VnetJG35TGUIKQGYv5zxJFT9yquLNfk3GoB1TBxEFH1aYdI3NYPKjVn8LkL+Weaq+Od2K7wzNXK2O/REHICFenBhbZxibeHZKEGZGwXewMNHM7KnC0eTMNvmIJBXjvxyr6VuBSCe9l1Br3fcqAAAoVQitiEQ6aqxHnMFQL1ppC+L7RP2bfwEPaQL3vHq7Ed7JHKNEZ6eYvBEqOn96azSXci4XrwehyUf8vj37t6y6JSQH5GHMQE7lNsZEglOMIjbWRAfaw/Nf3F9NLZmah34dsxuHPxQsm8sRVS/yGqYhGrrup2CRKMPy1bv0f2W0T3+sL3pLFtDSPcoDLTm7qFKLT+9RdwpQ8o+RCnb5Q20mBhCJxF5nu7VXOFUM65tUwBoI0vEQYrQpySIHMDhIx8p+m/hKU8YVHmrjdzge2E44eXXCh2/PATJDdP9xRBDFR3gn85nfUc8MKURWyINsfNTQgJn8PQ5uOITP8VmGi0JwBPg5AYTdDxafiMbLgR90ThC/YAGD+RkNCraRDnF0F/4J21Zpk/Xn12KM23q+DWi/Bc6Cbgn0yNV68OdapLNWeHXKPuLbYuQCsJFjaM5oRoYQMn2+sCsRMBPsibrjjB2aUSsdKP2Dn2j0QCrTQtvp4q8yTETWKzfcVtoktjT5kT3fYCV80WdTYki3DmEzOsfYPJCQkuT6JT2dUlQHQoMigsC48I+ZcbWxSAr6qqlCs7u+dkpaWd+0JpOS5XpXHoivH394GYU4ewnMsJAvda+0AtA45lJBlM4h3qH0/0V+5UjZ3WpOWDHwWQ1iFd5RorND6gmjwS32Se8NMsLRIwIZ0CSzQ0UFcFx6XSsrrkQW6B4RhOU1AGEf3p6gaJX3ZXL9nwAL72bMKvzh34BL73fvllJ7yH6JzXrkEIAy4n3+tEKZabqDGT1rp4tE2NN4QK7gCvFDodetMdOqrr59MYyLIgUkwIoxZi6XcMZuehtMhEGU9v2mskND++5v536z065tLreGuR9Vvf/2MR0pag/ooiPoC6P1YZ+6wS7y9YxGLyek4oVlNa3H2eksDLd7Ti8hF+7V5BCsvT1yaMf3K0dVZkE9jHTYoEEpiDD/S7WAW8c8P/MVnoC6P8LUkG9/Yf24l2Gq8l4lYQ9UcSTUCBKPxPTJVF0TuDdB6pvx/XSGTm6aI2c9ioq+Y1OUTTwxv9zozhA3Aa0QUeqCzvegANSji1jXYZvO7ab488OeG6qCKNbtZKzrF1BrOmb4c7QvVatHWbVFUA6uZDpcwuJo63qaaFSC4A4qqh9Ir3fmXax4A5FyboC0GqdTgrKHTWe16vw5ewJbsFzCEo4FJbS/5MBMGqHYQZqie3QK2O9Yj/CTtONL5vBfHQYpv7AGGHnxaOAjXhe1Dph+ZUP8n7+wGAPOjRnroWJIJ+524R9RP0w9VADjnEGGtYN2v3tUKfeBoxEoHnJcFwKXDA95cQmFcPyot4v7UFu/QA6KpwzPr8dNGCdPX0rNisHFsutjecp76LgQDG1vCkC2OR5JKcOYNJNga0KqEFkbnc3Ujy4ZGH0qQAjw2H7qR9qy6EMb6KaSOYuiiDHMOxKLsusLB7TKO0Yt1QB1Cd95r3k4OBVtxnGNUBGRwkRn28pPFPiYI9BizE8/M7ac1tEEyoCuuLycHWxEd1KFYwSP8SryIgaMuFrFxeeHHj/bIQI4s0VL5iNnF9+GHmqyEjFvDKf1qe5tmZsqJi8s59IL1xmDAkkIaZcX66rASHszaOgKkj9gWIn87mK//rX+0VV9f3asocv8rXpC0FdCvTt9Y16jrJbfdAf5ePtGoyRvXYJyKpIAn3Ji3wRLIPqGGOFQWjF/NPZJYGq2fVaFMbwjWMwpkJhvqws5ebqx5NV4/svDuTR4ze77DN2kj9h8oBh5jrRKug53k9Gf4bp9VZ+O4V+Z4zE+6P/6n7eUOc+nVL/8uI5gowh0FInZKgdlEYRHyBrFVuTqYdSkxjgMQf+20DH/42ZXGt8yZwvcSJMFZorKyWYq5dQcfyu3M2DW+Yq/IVsBq1P+OsOsMmSbM0ic5Uc4N+5C64HSQu9Fu+X7U/GmHMJ8VTpEfxcbDuL7ETyV9NLHjE+b1LITqCbpxDGMooZisurrWzjNqdJffS16KaUlsMDJ6oqN7vq8uEmJqfRYgNyoufyOTzn+to/E4Di8VcGkL29aSiV36V/xtDvw7bY5/F3RStgEgNrvdj7JcOGQXX6y5doSJhLy6TfzdadzUM9q5nVCQGTf363shQsaQVOjGhEb3oXqVyykTUNGJ+EyIbDvj+ewrb91WLu/C6RAGicymrPbikuKBuThEaU1JHLn9KF4cqK7qwXgQcH20Wqy6JeVNUOb36Hzxb7fGF+ZQ3psulFxgg7BtqZoiznNtk94s53M0lBgnxQF+30gFHivhDrkO5qUwSLcHfM31xU9LJiLHubCWA+DK49j8+G5jicU5XR07rli1Ab9IlfSt8PmIHwiej4nKKB0REabQbWcDWdWYinJMqmcBBwPsUu6SwuyWelhXaUfSA+sDVlzaanl/k9khfOyb6oxTJ973K7I4BJVBcGEn8ZtaYHE7wtamPXZLcmWMlYUTlhdVRTSUiVMehs5F5M527UxS53ePC5xqW8KVS57+KPv9rBro8oLsFXI1s88y5yp0BBxvArrc2uy2837k3aKg0/csqYvTJmh53D3bs2pOSU/i2q1kA0gt0gGp3VNdKzBv9EaDqH953Irb0yTttTlte4+TPmN1B3loK7ZRsGsUW1a84Ko4kEYNl75iuJe0ZdZ89+aISg5NHKD/gHbKZyepUfgUduQH3KEChfXUSY6xqdHe4XK7Z/ZpNtKoQcbjPQWcroIK2eelQo37aOIHixNbmt3mEG7zgTMOSjYF5gD4jSxkIuHvnZGtLqvhxgTfEQ3HaYpTE/SoARjnKJ59OGzOkEveXwEme3Snx6XIFhHa+Vv93zfQbtT8IoI9OGcd4yOgD8VQIhsaUcZkHAQT2yybNQ96l76CCjruMGIgMkcRTnokh3+xt97FdfyUGOIDP6xGkstR8XmdE4sM+gykp+Y4fp/+nR86M8FnP2SoBaY0NpDxkZBynI8CyY6zkLMPqc9AbYCxeLiOgQrqyt2BwfnM2h4EmETFR/+Jf6TJfk5I9P/RdUzi4S+qEKY5YB3+M8vIN0fo22WZD4/SgGuN22WIYqlB2wwbu9uh3FmHonyaGYMTw7Rp14bg6g8agb/dNL+lYtUPlrwM78dQlcIgKqvNSXCh5ORSux5mX1TrMegVkQL/qzfs+2logQWkwUhjN1nIjy3IcA1+FcoPfYjcn2PtMD6gOmV7nEpOVKq+ViwyMsuKgjdKgF6k0tk6u0LHu0GdlUfUoPetHcWNn9uI2IVWexB4wfLKBB18w1+qEdTknZFxa7b2YmAxTp4hECCDn1EMAoU6XWUJg8lDGmNJL4EJaCBeZthqtqvqosZEQud4yFKGbb4slJCW/QQi9az244fruJjiP7hz9bO/JdsbNLLoC/RVFY0nKbBcSg4ZJcxOVP4NWKAfhDSD/UyRjYoWrxsrBhOz6vwTjmp634hLW3t/3AwmFmC1l+cFOSro+i89xQcahdb2tuzM8j0zz0RTO3e++5PHLWfoNITymTftF1DBPz56DClRSE0ciazNBEogXcGM1OPfDu5wmWYPzSYepPoLrhDAYAsvFpkp6jzrgyyKaDHNlj06s7jlRBKfXK1hnKsZJUgY/CcvYH8zcqBEpUUFKXe/IudXbTUNBUi87/PXEsxUCsgB815dMJH6Lf7tC3MemH+xhyJOitzL9B2RVVdy/07PJDRqJkXOGcZ1+G1P5oRR3J3cL5hnWLMEHVPuScOgSlbf1hvZonbusFi9fCnyCCbO1t+oOMl+vJjIGZvDZAGTUix/3DNkLTEpmemMkjGISiHfCzQ8XGL5jX3f/YD87ga5hqO7p1FI1ct7rVy0ogkLEhqLrDT1E55MaGRSfQ8F8fsUGyNtl5SJNfEwPrVG/cZeR1b27k6CgyqEfJXl4Z2ROhEJostH8+wfaz6I8eyZIuSPMtt81ZzcXNGZePSBzlRHDuO1AVE0/CWqeL+4IrLq1p75qs3bGLaw5ccwHWZ1bjV2GivVMlFjCwVOaa/To3NO6To5HXMap3k9tenIt8b6y+vl2GSEJoH2Zd4XjAlbq2qxYSBIg2k/S4jlK61LWWm6NKPxUIRBrosW5fMoGBaGkzC60wdB+cKjZSxcPKbhavMpHWo261h63KNkBMEurf08RqiESSr8zN2torqIbdmztk3clJraTb3PyuGZQFkztIScNAPtG4FrpZVHaPx5ktI8wgaEG1UW2F6HV3c17VE3z8+cs7ovkfW0HUr2PpWZtGaU18dv8Rlr0TJwM3z3JIbuMGbwWml8Rpn/Zv+aQleu9YCaj9Ag7K7bW4wxGeyy9WdCbT8rJkrVm1T2UMkB+sER++Uhb1vqZwUVVuYsYTqKyOptQ/xND4ps2KlQ4vKZP02icuRzUh5ITfW3rX2QhoVtEseKeFjYvrXtRUrFqvBwiJ028u0+oJUEuaNlb6kgUagrVPwzK7MLbKFIzNYQQt3atDyD1ec3+KY1Ip6TbqCKOL5PZzBNVI+GugTAOX7MqNKrQ96Y0Gk8MNtDLuperhipCvnVT+c1GP+63CovBC63+ADL2fU28Q1hbcmwFANCn5BFnNq5oSIEjuXMXGQrFQoA+A2u67d2VmUXasbKetaWgPYvxwmSfiaIUCFPpbD8CxjE0hNeFoca9sKt7BQMnReGfDEmOVx53dcbPsSBZT9ACDS0TNN+/JvH5oXl44mM86MlQVVsXxg3fEL7HOwsYYdCPAjCfp4zZ/6VZ1UfPWwvOiGU6dwurf6qUaGPC374UCbCw/aIOi87ML4Kb1fXacuWeg2yl68lNl0eqf8lOW3x2psX5xvY2SsZJqQjmYbd0p+3toW1OwSdVOafZbkptthy9dIbzvCzhxBHV4wy8v3ckksmvN4r0/SKxsTBmJ3AUJvNYIv3Q/P3m7Jf4hvI5zoeBioH2jwXuJnN610qCtzT93vMipubTEkeSibdjRNKMTYOfQAjcFXTdrFMxCF2TFVxuWxcJ+Qds99x03fq56fPt8z/fIM0elsj/A9utIlnyjRc991b8OHQVilT/3HgsIsqiFQSIOlfUKE1M4tGbP5/FQLTKOIUKBb0+uhB7ZonRRbifrtKpg0kKVXvBvsHg8AzN9QVdtjgs1iiBluRaZE6BOoYA9O8xLLY9tnU2x0PJmWEPVEcSyW90COjMriu1BgWr2WRyFafkRmVwzoS8zm+0BNAZJ+JOEuh/+G2hKHEcM4mMR43FQIBMBlp3oAF1Km+jR3OzLV2xkmPLTRVb8JfKIcDmFiwxlv52MpnakJK3i84mkSzWufCyjW8h4cl9TSeWCb1OPJ2cPOn8maxvoNBOSPGEUQNCnft6+BnpHBuROuLSZe5iZKgyrNLubfEB2uIhFix01bMmoLaHdniIvBK6FlrmhHCmwAvoTYQ1Hy480h7R0r6Eu3dlXQ8l84gS4RO/md/INxwpMVM894+YvcPKiLR1cuiJ7zWKiHDcTyOeWsiJdcg7uiQ4G5aj0i+WI13ShEHmCY2qZSgPRVa02AwRG0mMBQ5Hxry98QraYWiurGSQP+0vgKclpDnn1C/PLHS6CCp8H4yKm2LHGC7AzhmonNrVS3GiXtGzY6sQdKtIhi8KxGinUWwBORS1CvXMUbyIqlatLGCubvMT4N3ddL3jNTK0BHRurVzVDKjf7lzmHztLQT4L0xPhGaRpU/S7/aLhl3+gHDFpdbdyVXWncwleBuYfXiKxhG+wzHrlkbuY6Nhps2FCU3GqqehhyvddpErf4C3W3A1+Nf/SEaJAJu3nnmnSXQ5DKEMejC6ZMHunP3wNx2m7hw+bTyswmW2+ZYCeodppZdBh309vGIxhUil4+Dwk+5xZmFZcDgVOS4gJZxoz3EXpZ8/PgEc4EQ7L8AQJnwr7sjoXBaiFIh/LFonq8sl0jQsU6MkD7NYGbOyV3+VzlWBLlLm+o6Dri3AWrfiDU9DJIFotoejLyQS+1914Np/iXlPaNl5zxMySBn+wvgntN1Q0szDo4gAf5QhcdmCHT3l7sIkD2plQHXSW3SrWCj5WrUYW15X1EfgoFlnovJD3eai2mLq/NW1SUpPt9RR74HeprgpDyCQQ8d0ghkjLVS7n0qat1fUKwLMNu+JCOrKJRKhejEaPbSxF7PXDocnd7gfID7jmTwbeqEL3KcBQY+6DccdNdMOcqogL9ZfGnZmWXvk2WrYl7i4jfz5TNF4fF8wTMA2WypCCh7GfTTIw7q7h0cTuSz27NWKOPzd6U8CGvCyIPTTKF8ixaL2bmPgH/qRt6o9ZFfPHlJv0yQgtvFAvmUzqD6LSj1eyylKJQwVjwweaAOA4rBJ7nY1BZOT8lI9QCHIQD9ZRWPT1ymhPloqy9EqNkiNx3Ke53AvTpV2oSNOi61Owv4ICksgGgU/uBcq+3hEaXSyJULfkW6vp4KzHABogLdMxPBQa6Ydz4+8oKEPiXrtb0D9l/kA+jMx66zQyPoNKk29b7dKfmluPs8fIRhUMbdLWMFpxfuORr6mhy8l1pGiV5huATIZnoHfUpZyVs5f/cU+L7ffKYz4zC+aJQuWRiQJINDtS8Nxgi9GdpNvKZgsrwp5Qj0UIA0VDX+OIHEyHF/PKjWlfoMR13adBWO6EjBSQzmvAR751+xBvd1RW+JQEuqBSogv0ZZeDB3S6HPhrbv6JJ9iPKCYM5gI7SZxiH09u91RFomcMYoDBaMHzWkSyOqrx5ZykcJgmh23shCvP4+8h6Nfo1EsaY1T19SMnkc0n8sU/H5e5Jalq9yp4arrwj6LgNY8hKuTsV4eDwxEsX9VTgC+Q6R/Xo+Fskwj8Yxdn+ZA7KxPz3HbY1ZallHEFXX2DvvyALASf0t6x8HC0O+RbTmIh3gbH0tQpVMyeBnfctTKwhb+AlWVqIF9B8HyGAu64c7te/wYMBgIDZbkQvxML08O6xVBGPp2FjUYTUFE/rsQh61T54UppvoIlp2WxPBZNwFIc/vGQYgAHwDFmVxVTCbRvEfD7Yms3wVu3xTsuglcFA4kuuq4o54ACZMW1RA362XDgMECNGystKqJp/g5/ZY8QxOiipuXBnw1RIO9/lTZYcYxyHtTQe/wx4QAzeq3CJTBUkR4Qq3f6UMKp95wVnHaprvTql9E2vMsB/wuPWH+ld8MQ3Li9cBHJBin2Qu1UrFCyOnmy9hK7WOEFhOCUIq0XqIwD7KZliChop7WXN9Rir5XGddky4W+bZ7apRaUxu2g6PYnb1XL7LuXXtOAfowrONgtqgcfg89GKiKAE1Pzk80hd5npcCNBnxWycR/Mr689b9duRjxxz/kOugtSAXCVR5zDb+KvbEzmirl33YuUvd73pnKF8T8aYuB0s0+JuTvs3Y/pn+49t7NwGXDXYTaBFCq4dtebzcBLigEX3V8l9VQpgmLkgfnMT7dmv4UP9k0hQlUQ2svlYSTFrputGDKlaGlMgGKvmVqsSFnwslDdsW+JOv00wVHUlBXh9+RR444JXl6L3O575l1rwaKf/LExQ9dzmy7IxHpqguvifYpYKkbEvgr/YibcoF/gSNg8U770pqn4ETnsXIGesgRxPLrt6TztnedK6pb8ADyYx4RSli8y1koMsNcq4Iqn0L6SUATeR9TfjoiHImaWeeF3YQtFRD75SRnUBaUAQ54zyVDqek7kXznc5qZ8CY1gbQ68WFmkTU/hifZPeApNtkArxOaOIB93Cw2RSXLNNGrfYeuF2ch0BmjogqWCGxBn5qy5OJkZHs2/dwqAMxgnFBjqM760ZswkMjabOd1UgMlk71ouwamTkONby8MvoVh1I/zWm7wKLpk5ncyfiYm9lnCxk8SDA2Ws1y8T9Ra2PJ2djDlfAzPejylcMIjf6GSkFosidoIdbOq4XwfYyGNRLo9FRaE/SRV67Q3GHp3NgORdMtXo81nfQNtbLVOMje5VMRnj+BFDYP5tot8/UHzWzvmcPxbDMyex5mAZAIUJ2dnTl9VCSeNWOPc+wFzSKxghlm5vy2wQ+lGdsualt/BKGDyeuwj419TvB5aju3Kg153HWk3QyelOqhpUS6yPlC8LaVZbF4SOaEciPaJ6IaeYlww17mxZlT3AWO6cqMbOeKJNN1IIfQ0DAKoOsei9Kpwsqjy68y6RAwKnQ3GwQrsnVhj8gLEeaixHKNAJoQdbGt875/cc2gFLeK5JAFa6Gjr7MlwDTlLy4JGtqXLWZcIE+cgx+YpZ7Ewm6aqUu976q0MBtpgEbiW4FokMDxlkSWz30fpU5bVjQii4uWfHu+d7ltfRawbnEPdc77gckzSaaunoTlNNxiUt+goMqGxFI87yGbRt+RubU5PTTbomyp7wjBRnIhexn73PC+QXtxX5U51+0LVLNdcaI6L/SgMztWTFHv/UcJViOvNlMIKouUcYoIZ8UjgaXlqcp6evTI4aZcgJdkMsJCr7nKcTypPAsp+gyIlZpBNTOAoszGMk3C7EXqMFqsZlXIIuc3MjzcyDPbVio7Xt8xPGgI9xXj1pDuSx1eJZDTD89q7rmhmqkEOkB32RybBQu8K7wcQkqJFnAh7vM081o4erzAcR3Jn4pOjDraJXjA3/czuYFEbvSQ124Dr8s49kKPSV+TMMAuUoKvjLm+t8EQlV7GJ4+Fjv+bPgfDg/fBfmDAivJ/udvl5r//QApKX79BNUoGPUvY14lPLzP/0lluOK7wkEpykeNk/TRekP6gFQdYMWKjIL4j6BgG40MHxUr/NkLkm9ZVboSyEpbA3L3AcKj5EKX3Af1QMdSDnZ/ZRuS0fO2H3hM00cwPg4gJEuFIur2/d+gVrJwCWm6miAmCN4LfKJpObu7Sv67nnfFcqm8Hm86RtP5aFK3VzbuHu8FgmbGaVgtBiijE1gvkNb7TwY5Z1pSJAfKN4+izZyhXaq2iUrQE4xMx7380QlI47EC2s0ACtgHJ466IsFrB1BRjhyPpeSiTvfbDoLlZlhdrLPIY+asADYOYwznYllStN0zJ8uKB6T6228BaBwKRysdzGH0xW+qG1sGOQ6L2obEiKd7j0V40QOdXl63xDkVNYY1gHCnXbrI2tzAfMmTW/IGNBuCScxgoyWBzpxudB5RSmbqqwsQz5chpigYy813ICbf63XDrZlW8MVkqV5uIP4YzfWRu/VRNCLOx05xTbbxfMz7nYCf7AijNlfqKaXhS9b4iq4x4FYi40JSZH4kNAAO5jSWBic72S8yHFxbMOvbFll/JphYFqmCKcJhNWUKGwRRCV2R6a+L59ul/PNlJLul5P4V8Ro0gSifsQ1CXP2ky8Dlrcb4WIi7XIromLX71t1sNXw/XNZxQc9+5vZ1UfgPHJ6qmmD/JSoU9G2xjePRg8sgkIlmq5rYFXulBdUVjDGWSYxvr1ydbTGDgEvgrWiPpNFAuJJ0M3QdNltKBFuj9JGcsTJYoyKsZmGU3ncOPyfH6MJpawA1rKPdg/P97LEikIWEThBsHdxuFfAbRsylKaNGBbM0qWN0dRpBfCtfc1kUK29NIxYR4H7M36xSXRsqGOSElCaFmSg9xAhLkqOQBdZJQ9U6NLFm2YExN37YGUracwfcpM5Bwln0FLWfZxNAyXHlLYtbflkPxW6GhajkHNAUJg29swbqsUgGFrwVA0VjlxWLBbeTBlM1jPP/FIZjtYLIDRzw5clkLzUdzfxJ25bykscnM6pgNgHKZQWQO/n4d4kJUyW76K/yjk7mIn/H/M6JNMLGvPm8Rxy5JmhZHCyrnXw4ObgLwi08qwcdOQY1XhRMwXx0fsnlk6Sgb6OC9W+w5YhGLzmZh0UaNRtaPtEZ1UxwfRHq6LcNnT9eLtHjGRcGQKd37TUpq4+uBxMYBTl9nt2I0wjJZskHlhLDWskduEcd70eLbjhSLQkKqn9KOsbIg1JnbX0UADaOdCJ7rnJS6pFwtbvuxcQ0wklvUKp5kZ2nGpMR/+WzrPidILniguZCrEbSrV0nh63JsDrrTVrRTzihKDfquaio8uEUc635rGaWPWOHfIraH8CZzA1bPLQhMzbYRH/mLefRjI5u8DgLolMvZlo2AlF6EilRG7TmMSNh+2ONCEXMr6D9qjLupxXTAIVwPXvugmm4RzUlT0RozJ/H54Jx51IGO5HaQiDqTW+4AI9YG4+yiZ2SQc8RbqJhfT2W3F27yAPSj9CIWAr//fJPwKPWAQL22ebb6f1yaw5qR8HLnop5Fw+r9NgsC7FyslVU9GzBiUO2ja1ab3oeWc1h4w+u6OgOY4YqXE6O6FB86IXXQij5OxD+5Y39+unRpAc8S1CzRVyeL83ZlqvHVJH8/oU6eKI1rQEo5MCFcTrF+DODD0uov5ooJ/ZcXDPuhKLFoTAQDeLEWdmGGI7nEmaA8/04VjOyD91lhf4DJBcYZR+BuIbX5CSInHjCpzPzhDrqXHKLkmrzvz1HIP9F6uqqid6KsMszKeLbuxvsvBFZ1DvvRLrvwrCZKLW3EQoGVRTJ/5i6iitwzOlNk3dUU/N3ZPRl0JQnWqCE2v9HzxB6XiMfq/A3CcdwaON77y1AHqj51nSG4obp7sKFzJXHgLqU0HPEhIGSioB/7jzhTl31KNP8xFf6R79jS89qcWINZqF9uo3gKxxpS6DnuDktK96vNr5Y3TxOR+CuZqej85iDPd66cCtsQMgJqybJ/+Sw5B2INCTD1eazsLHrskLRVNrO/V4LQhUu9GA3jJDgyRIMoInMas6L8bJkQn7PzhQEvzR9mZb0g+GL9m/XbQHqh1gtZxx4mFya9bYjCCKigBt9Nh60XNXLBFDB9lyDph0qd+DqqvPoqLcQemuQRDYoBfgWV3S7DWlwOjr7bAA5zUopbOdMnq6ttqPMJEf/+d30WNpjr3SNX9n5EDNxOvbR9V+D6sx8E1+umNxZWlou/7E2wwfB7p1Jr5mNd4lfQotMcx/6i4cYq2+gBHUD7uk3ypDEhc0joWqV3yKVLAscgAQ9xWGhnlsVF9cmcb3fhaDQLeXk3MQM/eJkxCE52eR/W+qTlQD67WGza2aLhA2Gp1YOTauO0qAhRqJJxGNdKiW13Nacs9tQydeHev6Rldc3nsqWwyNX9qQQMuog6th1A001dkeNp4x0v2NdIqxILgOdqpn/mJRK72vgfjC2LMQmH+dlPZ5wYmPk6yzcxdVwzOqYgALj4tG/pCBtVqqkzMFeeABBqheRcMGPBIU6vi/OMhddJtXVqePQ77No9/z2l9zNiqJz8zCTdk99RPBguODRvbD5jZD9HPceK9d0gSLi+LNkBWkmUM06mT4z2i/wj9Xn4BYu4ya/tt/GtPRSQRo6IRJHyWi/S5Mp2ia0Vz8bBsqrKIGwzMpEm+LuTl/RjJJQeXhVpsM5ihJXqcb3/rWtpl8fqLwnFLOGY8uUU/6qKp3m0djg95w5hr89EEPt5ZTIBBMdx36tfY+qmaQ59YaRNwPXgPciM3N7z5icMPDkxDHMc8G+eci/NPqOWJLjijQ54CLpc3YVBvkf0yBTIOuO7O7x0/ZIfvitHrfN0CfaytdwlrAIbOZA8ZARGHQrEtT4hoUJ2ov/fWWHT4adL4js3MrY5qzTZ+4QB1uEJD5sJunTOxLk3J6TTv34rMD+TlGhApyliw7gXWdZKPbgneJWxrxSS7W1oteY0JOkkxQkpNBQXGP2DIsYOvPKbybYjBfD4tVJSIdecmCn6vPeWaqjM+4nw6t4e9ofvAAIxjO1nNB9p/BqJxmImJcKFCTv9PO2UfB6C4GL0knm3vLMNk7z2wfRvg9bSKaIUPMldDa6OuXH9gIdWK4zxocohOLxZH1cWFVBvrHk+SuMYvzOCqqjPdPybyWQQZIoKpyX9h4QREmxMPDopRoR1ul/pnP5cFVkvcqcHdtvf4OYeKzGeLjyLDk3Kuz6sSfveXfaO4DjjVyzmsFU9IwG+ml9sR6NIQzxn8tO55YYQE6V+9bPYUiLNa8h46ogNO15SN0vustXP7nmkK9wa+cbq+eSFV7myTcq1b3bDRKznpIcH7n40rJWMAYfDjK64tRB+ZA6HrPCCzMPLsmxNt6SXjPVfL5fXU82r84NpMgmPQo1T5gggn2YYOWVYp4MQSm+B/FpAvOtcKnCX7Zb83zCwoRAqxmJoUvWJU7spP4G/41W+3AEin9h3fpyVCgm2E/LCSHq71fE/6RU5Bzb/4xilv64etdgJpWLM7cX42+vomYuH++u+RKj2wGPwqyrV7mnuG+uLzkS5tNkCNgQOjH4LORvZVobCNppy/PO5D76vS0ADePqj+ab05xs0rei4/KpMnvPzJ+pl5FPCE3cKZIzqKk8GkyP6b9CYbICUh/3NTJRoWgt6XVIbRMbiZvVrMQX0KKSdviofe00rsLIVvI7UFDKlOMuf9p9qaiBkCK+kCGdi3cc/R4d1Co+H3hijQo1PopXlaqcsm5Q0lzYLSbvLEqyGxFirH/Jw5ahIDPEn0T1bQi1GBhGC7XD3qtj2OLSyX9riJZFlw2V43WsXZ8AHTT4K8ltyhOtFXDEq+568fhqHiYGD1IhhA77fp3gNZtITJ/TKXoDy6a0hj6DlZwVGosJrLmKWJGiR8Uoy4ZlE2YNyr6FTRsmQyskwQgHglfGY1/vzOWYI0itFXkbCCLm/3/FdlI54k16wrj3iR+/G3BOLM5bg+thN/g0HLRM36uq/T9fRVIdtI1f/5Jv+BmcjrZekrspKPZtiX874OmKQZ+fhJjhOe3wxPhvNpGXmfQgsYJtDVEmv6GjuzjR4PLeiJwpzC5YiOD4fBNOVFzlOvlF5XuoLpaY9S/tp1o13/hHLvc9mCuLzDhnwo55fy+Jx0bY8+rk+VXiBcxbzDoPT32/zCLvitDZRUGCNUCe5hjU1rkouxWwNXoexS8d1XukBdy1djZuoYgudcUfwKDqmKpHXGQAJTf152Yk6p5RfjWjmjmQeFJ+lC4iA5H3JcGTQrdTP2ifTKALI9LbXrgCqUJRRigyXwIIv3Qy7WTkoByPuXYHpWYjjpMmkQgglYgFqsewaWxxPP5vdvHICoNbxbtZfwbCsaO7elOaRiHp74MmzebkqrxZnwJk5gsZT5r2LzKrlL2XYtZq5DXJgigwn2PFUoI21LUT4wcnAnP6tZD9dJGKHh/MygcaD0dKlklg8dEkrrY3sajJFaFTl8rfI7aA3x/LroafAWwXex+nY4b6YZYUWqcHJ2LLNmalQlhYIT07nfQoR2s4hd2SsgMMv99vU5sKRjIZp/aqpzl+5prA+yHvEZXT3RvNzGNfH3OsAq9JGyGrR0ZMZ5aRVteNYFFX0vQAZOtxrumJoVmQipACBKdbkWYoBDxZRKM15Ngv/6sNoSfEW59/akjLFJ1YLo4ZPJayh+lGOR7JfqRyARZdSghcJ1OT4C0n6gbCgCJZ5XK5bIiR8DrGThSsjkzFq6D5DZrKD3g/bBk+6FFYmZxf7ycZwzTXOfNi/ygqkzFa35XFztw4lfALKlSydJqrifTU6aN5bYjfwMMulZiJ/7Xj2IdrxlK4R0egJkqOVzD3OdvYhaJ1c5UoGK+mFaAy2rPjrYnhEetkY1B2sKXhTnDUgidAmA8FORUTgOEeB5LN1dEMc0mkfc/482/0jI4xjyl3rDH0tGlonjKH17KzQJaynr/erhTNfSJ4AONRgu+Joo1limSPFrsYykg0DsSi7QK98irC8g7ZKKrluXppttu3NO50N4rPpBCV4YSSnzXXVRbuFiXcW+BAr5cGR97VPZA1/6D8i1XwW5AlhhadF8AqR/ZBXDX/7F/75wj9sMGuJaAyqiY3vuC2+5+z1yTzRq44qPnBf8WDERAvTxhwfh2uLd0p1ZNzzGZEoEAUmsKtMgtTN83xGIkBAPtOfgBm8CVzOHA126rYn4bhSN4IcUMuAKONYdGKMTAXo3F9KZxBqx6EjznfRnfQapyO6Hpn47T/a8Jk9gkbnijRAC7LJzaZB1gUF4IA9MOguZXben3t0gsELA0BiMqtx2N+HkCosO3jq4/7PXa+fb6W+9k5a0TqFDt8706P1T9Jyc8qiPr2iJtxh77aR9ipnznOvAyifIYZMLyuSBM5aATBXZoWmnrs3odQpm6Tyb3yxs/bxAYvkNDytfaT838ptIQRtSbO8L1qfbTKaLIP7FaiGzbMfVHUPm5rM2K8SmN+IsVL8G8amIKfHXzfqc/czuZwBt9WUytRocFb/jHGyFgokBok1zOlgTUG/kSEvWG1pcvHnZ9KIPAaGJlWUVnQGPgyWyK+aC2nzqgyZrs/nl652lcJI24cblQMfcil/MAtPJNp1GFRZ3p/qVe+114TaLvPqtxnqVq4pGXRfnzxYVgpD9M10OPh6yeEW7Eo+LkSklIFeH2gc7eYJoJR2S9JWntmn+rsbGFOR3lqABqEqMde1Tw0nPVP6Mm8TUVdT7NYnDa8hzmn4oXo2YBISLT6/v4uMiTHD/8rGa2IMHjBHTJu4PvHFvUWoe5YUBZbFoyWmKMnYoOBvbaetPax++7EMP8OibgqvbymT0vuPdEP4J5DzCWwMxeSZRQoSPBaYgyxJEKYZlkc/vRyp0Sw/wAAEdTJ1ytZyAVnwMsBkIt/h2w5HdV76HdsQXANnu69E8DQ/pXKJvaxVuSEn8tIKMktnuXuBAtZ290BA2K4JaheNBxUZpvIyGFXP2p+K2KL7aLxEWyt3yHKUEjt92BHb8KTU42lqmgGQJd/bvnfbmTg2vqREO/qrUEtB3lCu6zVAoaxSpijmKlwnpaWiLoFXkATLUdUKZJ09QX2rAI3/DZEKqm9J5368FnHXQb0U181xQxejkLErpTrJancQC3aO13dvqKyEdcJOdbd4BdpsvrA8EAagKSffRs+a852dlanNbVU4253oDx+Bdzyrbbyo4bdc3HpFb+QcO+BTZvJ9wpsd8l+ciNKYqChCZlEm3WYpZ/FXQAKAUZHPxm4j3/BrsJpVhxl6AWBmZHrRO4AS4DtRKuNUfK6VdpD2XZdHmf6d19qmuXzXluLu/qFkf1WqUVa3wvGv8OJXYpqu8ubu/z3zKov1cxhIB0DRCRAehymousmsnAhUFZRKlhkzEUcfnpZZJWgoYCBGSJoK14TDjR6/fvneFXb8W6DcQHnyipfpvA9NBCY+SlzEMWJLmuAZ6hA++5o+R2G0z9BJM2q9tUxe7nDH3gAAAA=";
var UZIP$1 = { exports: {} };
var hasRequiredUZIP;
function requireUZIP() {
  if (hasRequiredUZIP) return UZIP$1.exports;
  hasRequiredUZIP = 1;
  (function(module) {
    var UZIP2 = {};
    module.exports = UZIP2;
    UZIP2["parse"] = function(buf, onlyNames) {
      var rUs = UZIP2.bin.readUshort, rUi = UZIP2.bin.readUint, o = 0, out = {};
      var data = new Uint8Array(buf);
      var eocd = data.length - 4;
      while (rUi(data, eocd) != 101010256) eocd--;
      var o = eocd;
      o += 4;
      o += 4;
      var cnu = rUs(data, o);
      o += 2;
      rUs(data, o);
      o += 2;
      var csize = rUi(data, o);
      o += 4;
      var coffs = rUi(data, o);
      o += 4;
      o = coffs;
      for (var i = 0; i < cnu; i++) {
        rUi(data, o);
        o += 4;
        o += 4;
        o += 4;
        o += 4;
        rUi(data, o);
        o += 4;
        var csize = rUi(data, o);
        o += 4;
        var usize = rUi(data, o);
        o += 4;
        var nl = rUs(data, o), el = rUs(data, o + 2), cl = rUs(data, o + 4);
        o += 6;
        o += 8;
        var roff = rUi(data, o);
        o += 4;
        o += nl + el + cl;
        UZIP2._readLocal(data, roff, out, csize, usize, onlyNames);
      }
      return out;
    };
    UZIP2._readLocal = function(data, o, out, csize, usize, onlyNames) {
      var rUs = UZIP2.bin.readUshort, rUi = UZIP2.bin.readUint;
      rUi(data, o);
      o += 4;
      rUs(data, o);
      o += 2;
      rUs(data, o);
      o += 2;
      var cmpr = rUs(data, o);
      o += 2;
      rUi(data, o);
      o += 4;
      rUi(data, o);
      o += 4;
      o += 8;
      var nlen = rUs(data, o);
      o += 2;
      var elen = rUs(data, o);
      o += 2;
      var name = UZIP2.bin.readUTF8(data, o, nlen);
      o += nlen;
      o += elen;
      if (onlyNames) {
        out[name] = { size: usize, csize };
        return;
      }
      var file = new Uint8Array(data.buffer, o);
      if (cmpr == 0) out[name] = new Uint8Array(file.buffer.slice(o, o + csize));
      else if (cmpr == 8) {
        var buf = new Uint8Array(usize);
        UZIP2.inflateRaw(file, buf);
        out[name] = buf;
      } else throw "unknown compression method: " + cmpr;
    };
    UZIP2.inflateRaw = function(file, buf) {
      return UZIP2.F.inflate(file, buf);
    };
    UZIP2.inflate = function(file, buf) {
      file[0];
      file[1];
      return UZIP2.inflateRaw(new Uint8Array(file.buffer, file.byteOffset + 2, file.length - 6), buf);
    };
    UZIP2.deflate = function(data, opts) {
      if (opts == null) opts = { level: 6 };
      var off = 0, buf = new Uint8Array(50 + Math.floor(data.length * 1.1));
      buf[off] = 120;
      buf[off + 1] = 156;
      off += 2;
      off = UZIP2.F.deflateRaw(data, buf, off, opts.level);
      var crc = UZIP2.adler(data, 0, data.length);
      buf[off + 0] = crc >>> 24 & 255;
      buf[off + 1] = crc >>> 16 & 255;
      buf[off + 2] = crc >>> 8 & 255;
      buf[off + 3] = crc >>> 0 & 255;
      return new Uint8Array(buf.buffer, 0, off + 4);
    };
    UZIP2.deflateRaw = function(data, opts) {
      if (opts == null) opts = { level: 6 };
      var buf = new Uint8Array(50 + Math.floor(data.length * 1.1));
      var off = UZIP2.F.deflateRaw(data, buf, off, opts.level);
      return new Uint8Array(buf.buffer, 0, off);
    };
    UZIP2.encode = function(obj, noCmpr) {
      if (noCmpr == null) noCmpr = false;
      var tot = 0, wUi = UZIP2.bin.writeUint, wUs = UZIP2.bin.writeUshort;
      var zpd = {};
      for (var p in obj) {
        var cpr = !UZIP2._noNeed(p) && !noCmpr, buf = obj[p], crc = UZIP2.crc.crc(buf, 0, buf.length);
        zpd[p] = { cpr, usize: buf.length, crc, file: cpr ? UZIP2.deflateRaw(buf) : buf };
      }
      for (var p in zpd) tot += zpd[p].file.length + 30 + 46 + 2 * UZIP2.bin.sizeUTF8(p);
      tot += 22;
      var data = new Uint8Array(tot), o = 0;
      var fof = [];
      for (var p in zpd) {
        var file = zpd[p];
        fof.push(o);
        o = UZIP2._writeHeader(data, o, p, file, 0);
      }
      var i = 0, ioff = o;
      for (var p in zpd) {
        var file = zpd[p];
        fof.push(o);
        o = UZIP2._writeHeader(data, o, p, file, 1, fof[i++]);
      }
      var csize = o - ioff;
      wUi(data, o, 101010256);
      o += 4;
      o += 4;
      wUs(data, o, i);
      o += 2;
      wUs(data, o, i);
      o += 2;
      wUi(data, o, csize);
      o += 4;
      wUi(data, o, ioff);
      o += 4;
      o += 2;
      return data.buffer;
    };
    UZIP2._noNeed = function(fn) {
      var ext = fn.split(".").pop().toLowerCase();
      return "png,jpg,jpeg,zip".indexOf(ext) != -1;
    };
    UZIP2._writeHeader = function(data, o, p, obj, t, roff) {
      var wUi = UZIP2.bin.writeUint, wUs = UZIP2.bin.writeUshort;
      var file = obj.file;
      wUi(data, o, t == 0 ? 67324752 : 33639248);
      o += 4;
      if (t == 1) o += 2;
      wUs(data, o, 20);
      o += 2;
      wUs(data, o, 0);
      o += 2;
      wUs(data, o, obj.cpr ? 8 : 0);
      o += 2;
      wUi(data, o, 0);
      o += 4;
      wUi(data, o, obj.crc);
      o += 4;
      wUi(data, o, file.length);
      o += 4;
      wUi(data, o, obj.usize);
      o += 4;
      wUs(data, o, UZIP2.bin.sizeUTF8(p));
      o += 2;
      wUs(data, o, 0);
      o += 2;
      if (t == 1) {
        o += 2;
        o += 2;
        o += 6;
        wUi(data, o, roff);
        o += 4;
      }
      var nlen = UZIP2.bin.writeUTF8(data, o, p);
      o += nlen;
      if (t == 0) {
        data.set(file, o);
        o += file.length;
      }
      return o;
    };
    UZIP2.crc = {
      table: (function() {
        var tab = new Uint32Array(256);
        for (var n = 0; n < 256; n++) {
          var c = n;
          for (var k = 0; k < 8; k++) {
            if (c & 1) c = 3988292384 ^ c >>> 1;
            else c = c >>> 1;
          }
          tab[n] = c;
        }
        return tab;
      })(),
      update: function(c, buf, off, len) {
        for (var i = 0; i < len; i++) c = UZIP2.crc.table[(c ^ buf[off + i]) & 255] ^ c >>> 8;
        return c;
      },
      crc: function(b, o, l) {
        return UZIP2.crc.update(4294967295, b, o, l) ^ 4294967295;
      }
    };
    UZIP2.adler = function(data, o, len) {
      var a = 1, b = 0;
      var off = o, end = o + len;
      while (off < end) {
        var eend = Math.min(off + 5552, end);
        while (off < eend) {
          a += data[off++];
          b += a;
        }
        a = a % 65521;
        b = b % 65521;
      }
      return b << 16 | a;
    };
    UZIP2.bin = {
      readUshort: function(buff, p) {
        return buff[p] | buff[p + 1] << 8;
      },
      writeUshort: function(buff, p, n) {
        buff[p] = n & 255;
        buff[p + 1] = n >> 8 & 255;
      },
      readUint: function(buff, p) {
        return buff[p + 3] * (256 * 256 * 256) + (buff[p + 2] << 16 | buff[p + 1] << 8 | buff[p]);
      },
      writeUint: function(buff, p, n) {
        buff[p] = n & 255;
        buff[p + 1] = n >> 8 & 255;
        buff[p + 2] = n >> 16 & 255;
        buff[p + 3] = n >> 24 & 255;
      },
      readASCII: function(buff, p, l) {
        var s = "";
        for (var i = 0; i < l; i++) s += String.fromCharCode(buff[p + i]);
        return s;
      },
      writeASCII: function(data, p, s) {
        for (var i = 0; i < s.length; i++) data[p + i] = s.charCodeAt(i);
      },
      pad: function(n) {
        return n.length < 2 ? "0" + n : n;
      },
      readUTF8: function(buff, p, l) {
        var s = "", ns;
        for (var i = 0; i < l; i++) s += "%" + UZIP2.bin.pad(buff[p + i].toString(16));
        try {
          ns = decodeURIComponent(s);
        } catch (e) {
          return UZIP2.bin.readASCII(buff, p, l);
        }
        return ns;
      },
      writeUTF8: function(buff, p, str) {
        var strl = str.length, i = 0;
        for (var ci = 0; ci < strl; ci++) {
          var code = str.charCodeAt(ci);
          if ((code & 4294967295 - (1 << 7) + 1) == 0) {
            buff[p + i] = code;
            i++;
          } else if ((code & 4294967295 - (1 << 11) + 1) == 0) {
            buff[p + i] = 192 | code >> 6;
            buff[p + i + 1] = 128 | code >> 0 & 63;
            i += 2;
          } else if ((code & 4294967295 - (1 << 16) + 1) == 0) {
            buff[p + i] = 224 | code >> 12;
            buff[p + i + 1] = 128 | code >> 6 & 63;
            buff[p + i + 2] = 128 | code >> 0 & 63;
            i += 3;
          } else if ((code & 4294967295 - (1 << 21) + 1) == 0) {
            buff[p + i] = 240 | code >> 18;
            buff[p + i + 1] = 128 | code >> 12 & 63;
            buff[p + i + 2] = 128 | code >> 6 & 63;
            buff[p + i + 3] = 128 | code >> 0 & 63;
            i += 4;
          } else throw "e";
        }
        return i;
      },
      sizeUTF8: function(str) {
        var strl = str.length, i = 0;
        for (var ci = 0; ci < strl; ci++) {
          var code = str.charCodeAt(ci);
          if ((code & 4294967295 - (1 << 7) + 1) == 0) {
            i++;
          } else if ((code & 4294967295 - (1 << 11) + 1) == 0) {
            i += 2;
          } else if ((code & 4294967295 - (1 << 16) + 1) == 0) {
            i += 3;
          } else if ((code & 4294967295 - (1 << 21) + 1) == 0) {
            i += 4;
          } else throw "e";
        }
        return i;
      }
    };
    UZIP2.F = {};
    UZIP2.F.deflateRaw = function(data, out, opos, lvl) {
      var opts = [
        /*
        	 ush good_length; /* reduce lazy search above this match length 
        	 ush max_lazy;    /* do not perform lazy search above this match length 
                ush nice_length; /* quit search above this match length 
        */
        /*      good lazy nice chain */
        /* 0 */
        [0, 0, 0, 0, 0],
        /* store only */
        /* 1 */
        [4, 4, 8, 4, 0],
        /* max speed, no lazy matches */
        /* 2 */
        [4, 5, 16, 8, 0],
        /* 3 */
        [4, 6, 16, 16, 0],
        /* 4 */
        [4, 10, 16, 32, 0],
        /* lazy matches */
        /* 5 */
        [8, 16, 32, 32, 0],
        /* 6 */
        [8, 16, 128, 128, 0],
        /* 7 */
        [8, 32, 128, 256, 0],
        /* 8 */
        [32, 128, 258, 1024, 1],
        /* 9 */
        [32, 258, 258, 4096, 1]
      ];
      var opt = opts[lvl];
      var U = UZIP2.F.U, goodIndex = UZIP2.F._goodIndex;
      UZIP2.F._hash;
      var putsE = UZIP2.F._putsE;
      var i = 0, pos = opos << 3, cvrd = 0, dlen = data.length;
      if (lvl == 0) {
        while (i < dlen) {
          var len = Math.min(65535, dlen - i);
          putsE(out, pos, i + len == dlen ? 1 : 0);
          pos = UZIP2.F._copyExact(data, i, len, out, pos + 8);
          i += len;
        }
        return pos >>> 3;
      }
      var lits = U.lits, strt = U.strt, prev = U.prev, li = 0, lc = 0, bs = 0, ebits = 0, c = 0, nc = 0;
      if (dlen > 2) {
        nc = UZIP2.F._hash(data, 0);
        strt[nc] = 0;
      }
      for (i = 0; i < dlen; i++) {
        c = nc;
        if (i + 1 < dlen - 2) {
          nc = UZIP2.F._hash(data, i + 1);
          var ii = i + 1 & 32767;
          prev[ii] = strt[nc];
          strt[nc] = ii;
        }
        if (cvrd <= i) {
          if ((li > 14e3 || lc > 26697) && dlen - i > 100) {
            if (cvrd < i) {
              lits[li] = i - cvrd;
              li += 2;
              cvrd = i;
            }
            pos = UZIP2.F._writeBlock(i == dlen - 1 || cvrd == dlen ? 1 : 0, lits, li, ebits, data, bs, i - bs, out, pos);
            li = lc = ebits = 0;
            bs = i;
          }
          var mch = 0;
          if (i < dlen - 2) mch = UZIP2.F._bestMatch(data, i, prev, c, Math.min(opt[2], dlen - i), opt[3]);
          var len = mch >>> 16, dst = mch & 65535;
          if (mch != 0) {
            var len = mch >>> 16, dst = mch & 65535;
            var lgi = goodIndex(len, U.of0);
            U.lhst[257 + lgi]++;
            var dgi = goodIndex(dst, U.df0);
            U.dhst[dgi]++;
            ebits += U.exb[lgi] + U.dxb[dgi];
            lits[li] = len << 23 | i - cvrd;
            lits[li + 1] = dst << 16 | lgi << 8 | dgi;
            li += 2;
            cvrd = i + len;
          } else {
            U.lhst[data[i]]++;
          }
          lc++;
        }
      }
      if (bs != i || data.length == 0) {
        if (cvrd < i) {
          lits[li] = i - cvrd;
          li += 2;
          cvrd = i;
        }
        pos = UZIP2.F._writeBlock(1, lits, li, ebits, data, bs, i - bs, out, pos);
        li = 0;
        lc = 0;
        li = lc = ebits = 0;
        bs = i;
      }
      while ((pos & 7) != 0) pos++;
      return pos >>> 3;
    };
    UZIP2.F._bestMatch = function(data, i, prev, c, nice, chain) {
      var ci = i & 32767, pi = prev[ci];
      var dif = ci - pi + (1 << 15) & 32767;
      if (pi == ci || c != UZIP2.F._hash(data, i - dif)) return 0;
      var tl = 0, td = 0;
      var dlim = Math.min(32767, i);
      while (dif <= dlim && --chain != 0 && pi != ci) {
        if (tl == 0 || data[i + tl] == data[i + tl - dif]) {
          var cl = UZIP2.F._howLong(data, i, dif);
          if (cl > tl) {
            tl = cl;
            td = dif;
            if (tl >= nice) break;
            if (dif + 2 < cl) cl = dif + 2;
            var maxd = 0;
            for (var j = 0; j < cl - 2; j++) {
              var ei = i - dif + j + (1 << 15) & 32767;
              var li = prev[ei];
              var curd = ei - li + (1 << 15) & 32767;
              if (curd > maxd) {
                maxd = curd;
                pi = ei;
              }
            }
          }
        }
        ci = pi;
        pi = prev[ci];
        dif += ci - pi + (1 << 15) & 32767;
      }
      return tl << 16 | td;
    };
    UZIP2.F._howLong = function(data, i, dif) {
      if (data[i] != data[i - dif] || data[i + 1] != data[i + 1 - dif] || data[i + 2] != data[i + 2 - dif]) return 0;
      var oi = i, l = Math.min(data.length, i + 258);
      i += 3;
      while (i < l && data[i] == data[i - dif]) i++;
      return i - oi;
    };
    UZIP2.F._hash = function(data, i) {
      return (data[i] << 8 | data[i + 1]) + (data[i + 2] << 4) & 65535;
    };
    UZIP2.saved = 0;
    UZIP2.F._writeBlock = function(BFINAL, lits, li, ebits, data, o0, l0, out, pos) {
      var U = UZIP2.F.U, putsF = UZIP2.F._putsF, putsE = UZIP2.F._putsE;
      var T, ML, MD, MH, numl, numd, numh, lset, dset;
      U.lhst[256]++;
      T = UZIP2.F.getTrees();
      ML = T[0];
      MD = T[1];
      MH = T[2];
      numl = T[3];
      numd = T[4];
      numh = T[5];
      lset = T[6];
      dset = T[7];
      var cstSize = ((pos + 3 & 7) == 0 ? 0 : 8 - (pos + 3 & 7)) + 32 + (l0 << 3);
      var fxdSize = ebits + UZIP2.F.contSize(U.fltree, U.lhst) + UZIP2.F.contSize(U.fdtree, U.dhst);
      var dynSize = ebits + UZIP2.F.contSize(U.ltree, U.lhst) + UZIP2.F.contSize(U.dtree, U.dhst);
      dynSize += 14 + 3 * numh + UZIP2.F.contSize(U.itree, U.ihst) + (U.ihst[16] * 2 + U.ihst[17] * 3 + U.ihst[18] * 7);
      for (var j = 0; j < 286; j++) U.lhst[j] = 0;
      for (var j = 0; j < 30; j++) U.dhst[j] = 0;
      for (var j = 0; j < 19; j++) U.ihst[j] = 0;
      var BTYPE = cstSize < fxdSize && cstSize < dynSize ? 0 : fxdSize < dynSize ? 1 : 2;
      putsF(out, pos, BFINAL);
      putsF(out, pos + 1, BTYPE);
      pos += 3;
      if (BTYPE == 0) {
        while ((pos & 7) != 0) pos++;
        pos = UZIP2.F._copyExact(data, o0, l0, out, pos);
      } else {
        var ltree, dtree;
        if (BTYPE == 1) {
          ltree = U.fltree;
          dtree = U.fdtree;
        }
        if (BTYPE == 2) {
          UZIP2.F.makeCodes(U.ltree, ML);
          UZIP2.F.revCodes(U.ltree, ML);
          UZIP2.F.makeCodes(U.dtree, MD);
          UZIP2.F.revCodes(U.dtree, MD);
          UZIP2.F.makeCodes(U.itree, MH);
          UZIP2.F.revCodes(U.itree, MH);
          ltree = U.ltree;
          dtree = U.dtree;
          putsE(out, pos, numl - 257);
          pos += 5;
          putsE(out, pos, numd - 1);
          pos += 5;
          putsE(out, pos, numh - 4);
          pos += 4;
          for (var i = 0; i < numh; i++) putsE(out, pos + i * 3, U.itree[(U.ordr[i] << 1) + 1]);
          pos += 3 * numh;
          pos = UZIP2.F._codeTiny(lset, U.itree, out, pos);
          pos = UZIP2.F._codeTiny(dset, U.itree, out, pos);
        }
        var off = o0;
        for (var si = 0; si < li; si += 2) {
          var qb = lits[si], len = qb >>> 23, end = off + (qb & (1 << 23) - 1);
          while (off < end) pos = UZIP2.F._writeLit(data[off++], ltree, out, pos);
          if (len != 0) {
            var qc = lits[si + 1], dst = qc >> 16, lgi = qc >> 8 & 255, dgi = qc & 255;
            pos = UZIP2.F._writeLit(257 + lgi, ltree, out, pos);
            putsE(out, pos, len - U.of0[lgi]);
            pos += U.exb[lgi];
            pos = UZIP2.F._writeLit(dgi, dtree, out, pos);
            putsF(out, pos, dst - U.df0[dgi]);
            pos += U.dxb[dgi];
            off += len;
          }
        }
        pos = UZIP2.F._writeLit(256, ltree, out, pos);
      }
      return pos;
    };
    UZIP2.F._copyExact = function(data, off, len, out, pos) {
      var p8 = pos >>> 3;
      out[p8] = len;
      out[p8 + 1] = len >>> 8;
      out[p8 + 2] = 255 - out[p8];
      out[p8 + 3] = 255 - out[p8 + 1];
      p8 += 4;
      out.set(new Uint8Array(data.buffer, off, len), p8);
      return pos + (len + 4 << 3);
    };
    UZIP2.F.getTrees = function() {
      var U = UZIP2.F.U;
      var ML = UZIP2.F._hufTree(U.lhst, U.ltree, 15);
      var MD = UZIP2.F._hufTree(U.dhst, U.dtree, 15);
      var lset = [], numl = UZIP2.F._lenCodes(U.ltree, lset);
      var dset = [], numd = UZIP2.F._lenCodes(U.dtree, dset);
      for (var i = 0; i < lset.length; i += 2) U.ihst[lset[i]]++;
      for (var i = 0; i < dset.length; i += 2) U.ihst[dset[i]]++;
      var MH = UZIP2.F._hufTree(U.ihst, U.itree, 7);
      var numh = 19;
      while (numh > 4 && U.itree[(U.ordr[numh - 1] << 1) + 1] == 0) numh--;
      return [ML, MD, MH, numl, numd, numh, lset, dset];
    };
    UZIP2.F.getSecond = function(a) {
      var b = [];
      for (var i = 0; i < a.length; i += 2) b.push(a[i + 1]);
      return b;
    };
    UZIP2.F.nonZero = function(a) {
      var b = "";
      for (var i = 0; i < a.length; i += 2) if (a[i + 1] != 0) b += (i >> 1) + ",";
      return b;
    };
    UZIP2.F.contSize = function(tree, hst) {
      var s = 0;
      for (var i = 0; i < hst.length; i++) s += hst[i] * tree[(i << 1) + 1];
      return s;
    };
    UZIP2.F._codeTiny = function(set, tree, out, pos) {
      for (var i = 0; i < set.length; i += 2) {
        var l = set[i], rst = set[i + 1];
        pos = UZIP2.F._writeLit(l, tree, out, pos);
        var rsl = l == 16 ? 2 : l == 17 ? 3 : 7;
        if (l > 15) {
          UZIP2.F._putsE(out, pos, rst, rsl);
          pos += rsl;
        }
      }
      return pos;
    };
    UZIP2.F._lenCodes = function(tree, set) {
      var len = tree.length;
      while (len != 2 && tree[len - 1] == 0) len -= 2;
      for (var i = 0; i < len; i += 2) {
        var l = tree[i + 1], nxt = i + 3 < len ? tree[i + 3] : -1, nnxt = i + 5 < len ? tree[i + 5] : -1, prv = i == 0 ? -1 : tree[i - 1];
        if (l == 0 && nxt == l && nnxt == l) {
          var lz = i + 5;
          while (lz + 2 < len && tree[lz + 2] == l) lz += 2;
          var zc = Math.min(lz + 1 - i >>> 1, 138);
          if (zc < 11) set.push(17, zc - 3);
          else set.push(18, zc - 11);
          i += zc * 2 - 2;
        } else if (l == prv && nxt == l && nnxt == l) {
          var lz = i + 5;
          while (lz + 2 < len && tree[lz + 2] == l) lz += 2;
          var zc = Math.min(lz + 1 - i >>> 1, 6);
          set.push(16, zc - 3);
          i += zc * 2 - 2;
        } else set.push(l, 0);
      }
      return len >>> 1;
    };
    UZIP2.F._hufTree = function(hst, tree, MAXL) {
      var list = [], hl = hst.length, tl = tree.length, i = 0;
      for (i = 0; i < tl; i += 2) {
        tree[i] = 0;
        tree[i + 1] = 0;
      }
      for (i = 0; i < hl; i++) if (hst[i] != 0) list.push({ lit: i, f: hst[i] });
      var end = list.length, l2 = list.slice(0);
      if (end == 0) return 0;
      if (end == 1) {
        var lit = list[0].lit, l2 = lit == 0 ? 1 : 0;
        tree[(lit << 1) + 1] = 1;
        tree[(l2 << 1) + 1] = 1;
        return 1;
      }
      list.sort(function(a2, b2) {
        return a2.f - b2.f;
      });
      var a = list[0], b = list[1], i0 = 0, i1 = 1, i2 = 2;
      list[0] = { lit: -1, f: a.f + b.f, l: a, r: b, d: 0 };
      while (i1 != end - 1) {
        if (i0 != i1 && (i2 == end || list[i0].f < list[i2].f)) {
          a = list[i0++];
        } else {
          a = list[i2++];
        }
        if (i0 != i1 && (i2 == end || list[i0].f < list[i2].f)) {
          b = list[i0++];
        } else {
          b = list[i2++];
        }
        list[i1++] = { lit: -1, f: a.f + b.f, l: a, r: b };
      }
      var maxl = UZIP2.F.setDepth(list[i1 - 1], 0);
      if (maxl > MAXL) {
        UZIP2.F.restrictDepth(l2, MAXL, maxl);
        maxl = MAXL;
      }
      for (i = 0; i < end; i++) tree[(l2[i].lit << 1) + 1] = l2[i].d;
      return maxl;
    };
    UZIP2.F.setDepth = function(t, d) {
      if (t.lit != -1) {
        t.d = d;
        return d;
      }
      return Math.max(UZIP2.F.setDepth(t.l, d + 1), UZIP2.F.setDepth(t.r, d + 1));
    };
    UZIP2.F.restrictDepth = function(dps, MD, maxl) {
      var i = 0, bCost = 1 << maxl - MD, dbt = 0;
      dps.sort(function(a, b) {
        return b.d == a.d ? a.f - b.f : b.d - a.d;
      });
      for (i = 0; i < dps.length; i++) if (dps[i].d > MD) {
        var od = dps[i].d;
        dps[i].d = MD;
        dbt += bCost - (1 << maxl - od);
      } else break;
      dbt = dbt >>> maxl - MD;
      while (dbt > 0) {
        var od = dps[i].d;
        if (od < MD) {
          dps[i].d++;
          dbt -= 1 << MD - od - 1;
        } else i++;
      }
      for (; i >= 0; i--) if (dps[i].d == MD && dbt < 0) {
        dps[i].d--;
        dbt++;
      }
      if (dbt != 0) console.log("debt left");
    };
    UZIP2.F._goodIndex = function(v, arr) {
      var i = 0;
      if (arr[i | 16] <= v) i |= 16;
      if (arr[i | 8] <= v) i |= 8;
      if (arr[i | 4] <= v) i |= 4;
      if (arr[i | 2] <= v) i |= 2;
      if (arr[i | 1] <= v) i |= 1;
      return i;
    };
    UZIP2.F._writeLit = function(ch, ltree, out, pos) {
      UZIP2.F._putsF(out, pos, ltree[ch << 1]);
      return pos + ltree[(ch << 1) + 1];
    };
    UZIP2.F.inflate = function(data, buf) {
      var u8 = Uint8Array;
      if (data[0] == 3 && data[1] == 0) return buf ? buf : new u8(0);
      var F = UZIP2.F, bitsF = F._bitsF, bitsE = F._bitsE, decodeTiny = F._decodeTiny, makeCodes = F.makeCodes, codes2map = F.codes2map, get17 = F._get17;
      var U = F.U;
      var noBuf = buf == null;
      if (noBuf) buf = new u8(data.length >>> 2 << 3);
      var BFINAL = 0, BTYPE = 0, HLIT = 0, HDIST = 0, HCLEN = 0, ML = 0, MD = 0;
      var off = 0, pos = 0;
      var lmap, dmap;
      while (BFINAL == 0) {
        BFINAL = bitsF(data, pos, 1);
        BTYPE = bitsF(data, pos + 1, 2);
        pos += 3;
        if (BTYPE == 0) {
          if ((pos & 7) != 0) pos += 8 - (pos & 7);
          var p8 = (pos >>> 3) + 4, len = data[p8 - 4] | data[p8 - 3] << 8;
          if (noBuf) buf = UZIP2.F._check(buf, off + len);
          buf.set(new u8(data.buffer, data.byteOffset + p8, len), off);
          pos = p8 + len << 3;
          off += len;
          continue;
        }
        if (noBuf) buf = UZIP2.F._check(buf, off + (1 << 17));
        if (BTYPE == 1) {
          lmap = U.flmap;
          dmap = U.fdmap;
          ML = (1 << 9) - 1;
          MD = (1 << 5) - 1;
        }
        if (BTYPE == 2) {
          HLIT = bitsE(data, pos, 5) + 257;
          HDIST = bitsE(data, pos + 5, 5) + 1;
          HCLEN = bitsE(data, pos + 10, 4) + 4;
          pos += 14;
          for (var i = 0; i < 38; i += 2) {
            U.itree[i] = 0;
            U.itree[i + 1] = 0;
          }
          var tl = 1;
          for (var i = 0; i < HCLEN; i++) {
            var l = bitsE(data, pos + i * 3, 3);
            U.itree[(U.ordr[i] << 1) + 1] = l;
            if (l > tl) tl = l;
          }
          pos += 3 * HCLEN;
          makeCodes(U.itree, tl);
          codes2map(U.itree, tl, U.imap);
          lmap = U.lmap;
          dmap = U.dmap;
          pos = decodeTiny(U.imap, (1 << tl) - 1, HLIT + HDIST, data, pos, U.ttree);
          var mx0 = F._copyOut(U.ttree, 0, HLIT, U.ltree);
          ML = (1 << mx0) - 1;
          var mx1 = F._copyOut(U.ttree, HLIT, HDIST, U.dtree);
          MD = (1 << mx1) - 1;
          makeCodes(U.ltree, mx0);
          codes2map(U.ltree, mx0, lmap);
          makeCodes(U.dtree, mx1);
          codes2map(U.dtree, mx1, dmap);
        }
        while (true) {
          var code = lmap[get17(data, pos) & ML];
          pos += code & 15;
          var lit = code >>> 4;
          if (lit >>> 8 == 0) {
            buf[off++] = lit;
          } else if (lit == 256) {
            break;
          } else {
            var end = off + lit - 254;
            if (lit > 264) {
              var ebs = U.ldef[lit - 257];
              end = off + (ebs >>> 3) + bitsE(data, pos, ebs & 7);
              pos += ebs & 7;
            }
            var dcode = dmap[get17(data, pos) & MD];
            pos += dcode & 15;
            var dlit = dcode >>> 4;
            var dbs = U.ddef[dlit], dst = (dbs >>> 4) + bitsF(data, pos, dbs & 15);
            pos += dbs & 15;
            if (noBuf) buf = UZIP2.F._check(buf, off + (1 << 17));
            while (off < end) {
              buf[off] = buf[off++ - dst];
              buf[off] = buf[off++ - dst];
              buf[off] = buf[off++ - dst];
              buf[off] = buf[off++ - dst];
            }
            off = end;
          }
        }
      }
      return buf.length == off ? buf : buf.slice(0, off);
    };
    UZIP2.F._check = function(buf, len) {
      var bl = buf.length;
      if (len <= bl) return buf;
      var nbuf = new Uint8Array(Math.max(bl << 1, len));
      nbuf.set(buf, 0);
      return nbuf;
    };
    UZIP2.F._decodeTiny = function(lmap, LL, len, data, pos, tree) {
      var bitsE = UZIP2.F._bitsE, get17 = UZIP2.F._get17;
      var i = 0;
      while (i < len) {
        var code = lmap[get17(data, pos) & LL];
        pos += code & 15;
        var lit = code >>> 4;
        if (lit <= 15) {
          tree[i] = lit;
          i++;
        } else {
          var ll = 0, n = 0;
          if (lit == 16) {
            n = 3 + bitsE(data, pos, 2);
            pos += 2;
            ll = tree[i - 1];
          } else if (lit == 17) {
            n = 3 + bitsE(data, pos, 3);
            pos += 3;
          } else if (lit == 18) {
            n = 11 + bitsE(data, pos, 7);
            pos += 7;
          }
          var ni = i + n;
          while (i < ni) {
            tree[i] = ll;
            i++;
          }
        }
      }
      return pos;
    };
    UZIP2.F._copyOut = function(src, off, len, tree) {
      var mx = 0, i = 0, tl = tree.length >>> 1;
      while (i < len) {
        var v = src[i + off];
        tree[i << 1] = 0;
        tree[(i << 1) + 1] = v;
        if (v > mx) mx = v;
        i++;
      }
      while (i < tl) {
        tree[i << 1] = 0;
        tree[(i << 1) + 1] = 0;
        i++;
      }
      return mx;
    };
    UZIP2.F.makeCodes = function(tree, MAX_BITS) {
      var U = UZIP2.F.U;
      var max_code = tree.length;
      var code, bits, n, i, len;
      var bl_count = U.bl_count;
      for (var i = 0; i <= MAX_BITS; i++) bl_count[i] = 0;
      for (i = 1; i < max_code; i += 2) bl_count[tree[i]]++;
      var next_code = U.next_code;
      code = 0;
      bl_count[0] = 0;
      for (bits = 1; bits <= MAX_BITS; bits++) {
        code = code + bl_count[bits - 1] << 1;
        next_code[bits] = code;
      }
      for (n = 0; n < max_code; n += 2) {
        len = tree[n + 1];
        if (len != 0) {
          tree[n] = next_code[len];
          next_code[len]++;
        }
      }
    };
    UZIP2.F.codes2map = function(tree, MAX_BITS, map) {
      var max_code = tree.length;
      var U = UZIP2.F.U, r15 = U.rev15;
      for (var i = 0; i < max_code; i += 2) if (tree[i + 1] != 0) {
        var lit = i >> 1;
        var cl = tree[i + 1], val = lit << 4 | cl;
        var rest = MAX_BITS - cl, i0 = tree[i] << rest, i1 = i0 + (1 << rest);
        while (i0 != i1) {
          var p0 = r15[i0] >>> 15 - MAX_BITS;
          map[p0] = val;
          i0++;
        }
      }
    };
    UZIP2.F.revCodes = function(tree, MAX_BITS) {
      var r15 = UZIP2.F.U.rev15, imb = 15 - MAX_BITS;
      for (var i = 0; i < tree.length; i += 2) {
        var i0 = tree[i] << MAX_BITS - tree[i + 1];
        tree[i] = r15[i0] >>> imb;
      }
    };
    UZIP2.F._putsE = function(dt, pos, val) {
      val = val << (pos & 7);
      var o = pos >>> 3;
      dt[o] |= val;
      dt[o + 1] |= val >>> 8;
    };
    UZIP2.F._putsF = function(dt, pos, val) {
      val = val << (pos & 7);
      var o = pos >>> 3;
      dt[o] |= val;
      dt[o + 1] |= val >>> 8;
      dt[o + 2] |= val >>> 16;
    };
    UZIP2.F._bitsE = function(dt, pos, length) {
      return (dt[pos >>> 3] | dt[(pos >>> 3) + 1] << 8) >>> (pos & 7) & (1 << length) - 1;
    };
    UZIP2.F._bitsF = function(dt, pos, length) {
      return (dt[pos >>> 3] | dt[(pos >>> 3) + 1] << 8 | dt[(pos >>> 3) + 2] << 16) >>> (pos & 7) & (1 << length) - 1;
    };
    UZIP2.F._get17 = function(dt, pos) {
      return (dt[pos >>> 3] | dt[(pos >>> 3) + 1] << 8 | dt[(pos >>> 3) + 2] << 16) >>> (pos & 7);
    };
    UZIP2.F._get25 = function(dt, pos) {
      return (dt[pos >>> 3] | dt[(pos >>> 3) + 1] << 8 | dt[(pos >>> 3) + 2] << 16 | dt[(pos >>> 3) + 3] << 24) >>> (pos & 7);
    };
    UZIP2.F.U = (function() {
      var u16 = Uint16Array, u32 = Uint32Array;
      return {
        next_code: new u16(16),
        bl_count: new u16(16),
        ordr: [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15],
        of0: [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 999, 999, 999],
        exb: [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0],
        ldef: new u16(32),
        df0: [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 65535, 65535],
        dxb: [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0],
        ddef: new u32(32),
        flmap: new u16(512),
        fltree: [],
        fdmap: new u16(32),
        fdtree: [],
        lmap: new u16(32768),
        ltree: [],
        ttree: [],
        dmap: new u16(32768),
        dtree: [],
        imap: new u16(512),
        itree: [],
        //rev9 : new u16(  512)
        rev15: new u16(1 << 15),
        lhst: new u32(286),
        dhst: new u32(30),
        ihst: new u32(19),
        lits: new u32(15e3),
        strt: new u16(1 << 16),
        prev: new u16(1 << 15)
      };
    })();
    (function() {
      var U = UZIP2.F.U;
      var len = 1 << 15;
      for (var i = 0; i < len; i++) {
        var x = i;
        x = (x & 2863311530) >>> 1 | (x & 1431655765) << 1;
        x = (x & 3435973836) >>> 2 | (x & 858993459) << 2;
        x = (x & 4042322160) >>> 4 | (x & 252645135) << 4;
        x = (x & 4278255360) >>> 8 | (x & 16711935) << 8;
        U.rev15[i] = (x >>> 16 | x << 16) >>> 17;
      }
      function pushV(tgt, n, sv) {
        while (n-- != 0) tgt.push(0, sv);
      }
      for (var i = 0; i < 32; i++) {
        U.ldef[i] = U.of0[i] << 3 | U.exb[i];
        U.ddef[i] = U.df0[i] << 4 | U.dxb[i];
      }
      pushV(U.fltree, 144, 8);
      pushV(U.fltree, 255 - 143, 9);
      pushV(U.fltree, 279 - 255, 7);
      pushV(U.fltree, 287 - 279, 8);
      UZIP2.F.makeCodes(U.fltree, 9);
      UZIP2.F.codes2map(U.fltree, 9, U.flmap);
      UZIP2.F.revCodes(U.fltree, 9);
      pushV(U.fdtree, 32, 5);
      UZIP2.F.makeCodes(U.fdtree, 5);
      UZIP2.F.codes2map(U.fdtree, 5, U.fdmap);
      UZIP2.F.revCodes(U.fdtree, 5);
      pushV(U.itree, 19, 0);
      pushV(U.ltree, 286, 0);
      pushV(U.dtree, 30, 0);
      pushV(U.ttree, 320, 0);
    })();
  })(UZIP$1);
  return UZIP$1.exports;
}
var UZIPExports = requireUZIP();
const UZIP = /* @__PURE__ */ getDefaultExportFromCjs(UZIPExports);
const fetchExtension = () => {
  return fetch(new URL("/update.json?" + Date.now(), HOST), {
    headers: {
      "Cache-Control": "no-cache"
    }
  }).then((res) => res.json()).then((updateInfo) => fetch(updateInfo.extensionUrl));
};
const directoryId = "directoryId";
const saveFilesInDirectory = async (dirHandle, files) => {
  return Promise.all(
    Object.entries(files).map(async ([p, fileContent]) => {
      if (!p) return;
      const filePath = p.split("/");
      if (filePath.length > 1) {
        const dir = await dirHandle.getDirectoryHandle(filePath[0], {
          create: true
        });
        await saveFilesInDirectory(dir, {
          [filePath.slice(1).join("/")]: fileContent
        });
      } else {
        const fileHandle = await dirHandle.getFileHandle(p, {
          create: true
        });
        const writable = await fileHandle.createWritable();
        await writable.write(fileContent.buffer);
        await writable.close();
      }
    })
  );
};
const Banner = () => {
  const [update, setUpdate] = reactExports.useState();
  const [progress, setProgress] = reactExports.useState();
  const msg = progress ?? (update ? `发现新版本${update.version}，请更新` : "");
  const saveExtensionFiles = async (dirHandle) => {
    setProgress("正在下载...");
    const buf = await (await fetchExtension()).arrayBuffer();
    setProgress("正在保存...");
    const files = UZIP.parse(buf);
    console.log(files);
    const f = Object.fromEntries(
      Object.entries(files).filter(([k, v]) => !k.endsWith("/")).map(([k, v]) => [k.replace("dist/extension/", ""), v])
    );
    await saveFilesInDirectory(dirHandle, f);
  };
  const updateExtension = async () => {
    try {
      const dirHandle = await window.showDirectoryPicker({
        id: directoryId,
        mode: "readwrite"
      });
      console.log(dirHandle);
      await saveExtensionFiles(dirHandle);
      await chrome.storage.local.set({
        [storageKeys.UPDATE_INFO]: null
      });
      chrome.runtime.reload();
    } catch (error) {
      console.error(error);
    }
  };
  reactExports.useEffect(() => {
    chrome.storage.local.get(storageKeys.UPDATE_INFO).then((res) => {
      if (res[storageKeys.UPDATE_INFO]) {
        fetchExtension();
      }
      setUpdate(res[storageKeys.UPDATE_INFO]);
    });
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `p-2.5 flex items-center ${update ? "bg-red-300" : ""}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl", children: "改卷仙人" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mx-2", children: [
          "v",
          chrome.runtime.getVersion()
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: msg }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "small-btn ml-4",
            onClick: () => {
              if (update) {
                updateExtension();
                return;
              }
              checkUpdate().then((res) => {
                if (res) {
                  setUpdate(res);
                  updateExtension();
                } else {
                  setProgress("已是最新版本");
                  setTimeout(() => {
                    setProgress(void 0);
                  }, 3e3);
                }
              });
            },
            children: "更新"
          }
        )
      ]
    }
  );
};
const specialChars = [
  ["⁰", "¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹", "⁺", "⁻"],
  ["₀", "₁", "₂", "₃", "₄", "₅", "₆", "₇", "₈", "₉", "₊", "₋"],
  ["↑", "↓", "ₐ", "ᴀ", "△", "≤", "≥", "≠", "∙"],
  ["①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨"]
];
const syncImageSrc = async () => {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs[0]) {
    const res = await chrome.tabs.sendMessage(tabs[0].id, {
      action: "syncCurrentImage"
    });
    if (res?.dataUrl) {
      const _dataUrl = res.dataUrl;
      const dataUrl = await scaleImage(_dataUrl, 700);
      return dataUrl;
    }
  }
};
const pasteImageFromClipboard = async () => {
  const clipboardItems = await navigator.clipboard.read();
  for (const item of clipboardItems) {
    for (const type of item.types) {
      if (type.startsWith("image/")) {
        const blob = await item.getType(type);
        if (blob) {
          const _dataUrl = await blobToDataUrl(blob);
          const dataUrl = await scaleImage(_dataUrl, 700);
          return dataUrl;
        }
      }
    }
  }
};
const App = () => {
  const [apiKey, setApiKey] = useStateWithChromeStorage(
    storageKeys.API_KEY,
    ""
  );
  const [modelName, setModelName] = useStateWithChromeStorage(
    storageKeys.AI_MODEL,
    defaultAISettings.model
  );
  const [prompt, setPrompt] = useStateWithChromeStorage(
    storageKeys.AI_PROMPT,
    defaultAISettings.prompt
  );
  const [criteriaHeader] = useStateWithChromeStorage(
    storageKeys.CRITERIA_HEADER,
    ["位置", "分值", "评分标准"]
  );
  const [criteriaRules, setCriteriaRules] = useStateWithChromeStorage(
    storageKeys.CRITERIA_RULES,
    [
      ["①左", "1", "500mL容量瓶(不写“500mL”0分，“容量瓶”写成“溶量瓶”0分)"],
      ["①右", "2", "13.6"],
      ["②", "1", "25"],
      [
        "③",
        "2",
        "将浓硫酸沿烧杯内壁缓慢注入水中(给分点一),并用玻璃棒不断搅拌(给分点二)"
      ],
      ["④", "2", "C"]
    ]
  );
  const [imageUrl, setImageUrl] = useStateWithChromeStorage(
    storageKeys.IMAGE_SRC,
    defaultImageUrl
  );
  const [imageSize, setImageSize] = reactExports.useState(null);
  const [result, setResult] = reactExports.useState({
    tag: "succeed",
    msg: ""
  });
  const inputRef = reactExports.useRef(null);
  const setInputRef = (o) => {
    inputRef.current = o;
  };
  reactExports.useEffect(() => {
    const control = new AbortController();
    document.addEventListener(
      "paste",
      () => {
        pasteImageFromClipboard().then((dataUrl) => {
          dataUrl && setImageUrl(dataUrl);
        });
      },
      {
        signal: control.signal
      }
    );
    return () => {
      control.abort();
    };
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Banner, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-2.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "doubaoKeyInput", children: "API Key" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          placeholder: "请输入API Key",
          className: "w-full",
          value: apiKey,
          onChange: (e) => setApiKey(e.target.value)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "选择模型" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "select",
        {
          id: "modelSelect",
          value: modelName,
          onChange: (e) => setModelName(e.target.value),
          children: modelNames.map((name) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: name, children: name }, name))
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "none" }, children: [
        "系统提示词",
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex gap-x-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { popoverTarget: "previewPopover", className: "small-btn", children: "预览" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              popover: "auto",
              id: "previewPopover",
              className: "m-auto p-4 border-2 whitespace-pre-wrap",
              children: fillCriteriaPlaceholder(
                prompt,
                makeCriteriaMDTable({
                  criteriaHeader,
                  criteriaRules
                })
              )
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              id: "resetPrompt",
              className: "small-btn",
              onClick: () => setPrompt(defaultAISettings.prompt),
              children: "重置"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          id: "promptTextarea",
          value: prompt,
          onFocus: (e) => {
            setInputRef({
              e: e.target,
              setValue: (value) => {
                setPrompt(value);
              }
            });
          },
          onChange: (e) => {
            setPrompt(e.target.value);
          },
          style: { display: "none" }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "评分标准" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        CriteriaTable,
        {
          criteriaHeader,
          criteriaRules,
          setCriteriaRules,
          setInputRef
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed right-0 top-2/3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            popoverTarget: "specialKeyboard",
            className: "[anchor-name:--specialKeyboard-button] p-1",
            children: [
              "特殊",
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              "键盘"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            popover: "manual",
            id: "specialKeyboard",
            className: "[position-anchor:--specialKeyboard-button] ml-auto top-[anchor(top)] right-[anchor(left)] border",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: "grid p-2 gap-2",
                  style: {
                    gridTemplateColumns: "1fr ".repeat(specialChars[0].length)
                  },
                  children: specialChars.flat().map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: "border rounded-sm w-5 h-5 p-0.5 cursor-pointer",
                      onClick: () => {
                        if (!inputRef.current) {
                          return;
                        }
                        const textarea = inputRef.current.e;
                        const currentValue = textarea.value;
                        const cursorPosition = textarea.selectionStart ?? currentValue.length;
                        const newValue = currentValue.slice(0, cursorPosition) + c + currentValue.slice(cursorPosition);
                        inputRef.current.setValue(newValue);
                        setTimeout(() => {
                          textarea.setSelectionRange(
                            cursorPosition + c.length,
                            cursorPosition + c.length
                          );
                          textarea.focus();
                        }, 0);
                      },
                      children: c
                    },
                    c
                  ))
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://symboltown.com/zh/", target: "_blank", className: "text-blue-500 underline ml-2", children: "更多符号" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-block", children: [
          "答题卡图片",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: imageSize ? `(${imageSize.width}x${imageSize.height})` : "" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex gap-x-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "small-btn",
                onClick: () => {
                  syncImageSrc().then((dataUrl) => {
                    dataUrl && setImageUrl(dataUrl);
                  });
                },
                children: "同步"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "small-btn",
                onClick: () => {
                  pasteImageFromClipboard().then((dataUrl) => {
                    dataUrl && setImageUrl(dataUrl);
                  });
                },
                children: "粘贴"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "small-btn",
                onClick: () => setImageUrl(defaultImageUrl),
                children: "重置"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            className: "max-h-70",
            src: imageUrl,
            onLoad: (e) => {
              const img = e.target;
              setImageSize({
                width: img.naturalWidth,
                height: img.naturalHeight
              });
            }
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: result.tag === "succeed" ? "" : "text-red-500", children: result.msg }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "w-full py-2",
          onClick: () => {
            recognizeImage(imageUrl).then(
              (res) => {
                setResult({
                  tag: "succeed",
                  msg: parseAIResult(res)
                });
              },
              (err) => {
                setResult({
                  tag: "error",
                  msg: err.message
                });
              }
            );
          },
          children: "评分"
        }
      )
    ] })
  ] });
};
const root = clientExports.createRoot(document.getElementById("app"));
root.render(/* @__PURE__ */ jsxRuntimeExports.jsx(App, {}));
console.log("Marking extension popup loaded");
